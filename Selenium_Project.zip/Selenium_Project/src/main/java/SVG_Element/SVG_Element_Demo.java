package SVG_Element;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SVG_Element_Demo {

	public static void main(String[] args) throws InterruptedException {
		

		// Create object of the ChromeOptions
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		  // Define explicit wait with a 10-second timeout
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");	
		
		// Locate username input using xpath  :  //input[@name='username' and @placeholder='Username']
		// Admin is username
		WebElement usrename =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username' and @placeholder='Username']")));
		usrename.sendKeys("Admin");
		 

		// Time delay
		Thread.sleep(2000);
		
		// Locate the password input using xpath : //input[@name='password' and @placeholder='Password']
		// admin123 is password
		WebElement password = driver.findElement(By.xpath("//input[@name='password' and @placeholder='Password']"));
		password.sendKeys("admin123");
		
		// Locate login element using xpath : //button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button' and @type='submit']
		WebElement submit_btn = driver.findElement(By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button' and @type='submit']"));
		submit_btn.click();
		
		// Time delay
		Thread.sleep(2000);
		
		
		// Not Locating svg element using svg tag, using Text
		
		// svg element does not support Absolute Xpath
		// Locate svg element using relative xpath : //*[text()='Time']   or    //span[normalize-space()='Time']
		//WebElement time = driver.findElement(By.xpath("//span[normalize-space()='Time']"));
		
		//WebElement time = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Time']")));
		//time.click();
		
		
		// Not working 
		// Locating element using svg using xpath :  //a[@class='oxd-icon oxd-main-menu-item--icon']//*[name()='svg']
		//WebElement time = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='oxd-icon oxd-main-menu-item--icon']//*[name()='svg']")));
		//time.click();
		
		//          //button[@title='Timesheets']//*[name()='svg']
		WebElement time = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Timesheets']//*[name()='svg']")));
		time.click();
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
		
	}

}
