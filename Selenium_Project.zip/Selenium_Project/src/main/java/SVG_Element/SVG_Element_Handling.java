package SVG_Element;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SVG_Element_Handling {
	
	//   https://books-pwakit.appspot.com/
	//   https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
	//   https://www.geeksforgeeks.org/
	
	
	public static void main(String[] args) throws InterruptedException {
		

		// Create object of the ChromeOptions
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		  // Define explicit wait with a 10-second timeout
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://www.geeksforgeeks.org/
		driver.get("https://www.geeksforgeeks.org/");	
		
		
		//  //*[name()='svg']//*[local-name()='path'][1]
		// Locating svg path element 
		List<WebElement> paths = driver.findElements(By.xpath("//*[name()='svg']//*[local-name()='path']"));
//		
//		for(WebElement path : paths)
//		{
//			String path_d_attribute_value = path.getAttribute("d");
//			System.out.println("Path : "+path_d_attribute_value);
//		}
//		
		for(int i=0 ; i < paths.size() ; i++)
		{
			String path_d_value = paths.get(i).getAttribute("d");
			System.out.println("Path "+i+" values : "+path_d_value);
		}
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
		
	}

}
