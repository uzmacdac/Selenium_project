package Calendar_And_Date;

import java.time.Duration;
import java.time.Month;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Date_Picker_2 {

	
	public static Month convertMonth(String month) {
		
		// Defining HashMap to map the month
		HashMap<String, Month> monthMap = new HashMap<String, Month>();
		
		// adding element in map
		monthMap.put("January", Month.JANUARY);
		monthMap.put("Februray", Month.FEBRUARY);
		monthMap.put("March", Month.MARCH);
		monthMap.put("April", Month.APRIL);
		monthMap.put("May", Month.MAY);
		monthMap.put("June", Month.JUNE);
		monthMap.put("July", Month.JULY);
		monthMap.put("August", Month.AUGUST);
		monthMap.put("September", Month.SEPTEMBER);
		monthMap.put("October", Month.OCTOBER);
		monthMap.put("November", Month.NOVEMBER);
		monthMap.put("December", Month.DECEMBER);
		
		// get the value of the month
		Month month_value = monthMap.get(month);
		
		if(month_value == null)
		{
			System.out.println("Invalid Month");
			
		}
		
		
		return month_value;
		
	}
	
	public static void selectDate(WebDriver driver, String required_year, String required_month, String required_date) {
		
		// Year dropdown xpath : //select[@class='ui-datepicker-year']
		WebElement year_dropdown = driver.findElement(By.xpath("//select[@class='ui-datepicker-year']"));
				
		// select the option
		Select options = new Select(year_dropdown);
		
		// select year from the drop down
		options.selectByVisibleText(required_year);
				
		while(true)
		{			// This loop will continue to execute ntil the required month and displayed month are same 
			// Select Month
			String displayed_month = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
					
			// Convert required month and displayed month
			Month expectedMonth = convertMonth(required_month);
					
			// Convert Displayed month
			Month currentMonth = convertMonth(displayed_month);
					
			// compare expectedMonth with currenMonth
			// compareTo() return -> 0  -> exactly same. expectedMonth are equal to currentMonth
			//                    -> <0 -> means it is past month
			//                    -> >0 -> means it is future month 
			int result = expectedMonth.compareTo(currentMonth);
			if(result < 0)
			{
				// Past Month
				driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
			}
			else if(result > 0)
			{
				// Future Month
				driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
			}
			else
			{
				// required month and displayed month are same
				break;
			}
					
		}
			
		// select the date 
		List<WebElement> all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td//a"));
				
		// traverse all date until find the desire one
		for(WebElement date : all_dates)
		{
			// date is equal to required date. if it is equal then click on it
			if(date.getText().equals(required_date))
			{
				date.click();
				break;
			}
		}
				
				
		
	}
	
	
	
	public static void main(String[] args) throws InterruptedException {

		// Launch Chrome Driver
		WebDriver driver = new ChromeDriver();
				
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
							
		// Maximize Browser window
		driver.manage().window().maximize();
											
		// Open url : https://www.globalsqa.com/demo-site/datepicker/#Simple%20Date%20Picker
		driver.get("https://www.globalsqa.com/demo-site/datepicker/#Simple%20Date%20Picker");
		
		// xpath for Simple Date Picker :  //ul//li[@id='Simple Date Picker']
		WebElement simple_date_picker_link = driver.findElement(By.xpath("//ul//li[@id='Simple Date Picker']"));
		
		
		
		// xpath for Icon Date Picker : //ul//li[@id='Icon Trigger']
		WebElement icon_date_picker_link = driver.findElement(By.xpath("//ul//li[@id='Icon Trigger']"));
		//icon_date_picker_link.click();
		
		// xpath for Dropdown Date Picker : //ul//li[@id='DropDown DatePicker']
		WebElement dropdown_date_picker_link = driver.findElement(By.xpath("//ul//li[@id='DropDown DatePicker']"));
		dropdown_date_picker_link.click();
		

		WebElement info_msg = driver.findElement(By.xpath("(//a[@class='close_img'])[2]"));
		info_msg.click();
		//((WebElement) wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("(//a[@class='close_img'])[2]")))).click();
		
		
		// Time Delay
		//Thread.sleep(2000);
		
		// switching to iframe using webElement xpath : //iframe[@class='demo-frame lazyloaded']
		//driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='demo-frame lazyloaded']")));
		
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@class='demo-frame lazyloaded']")));
		
		// time delay
		Thread.sleep(3000);
		
		
		// click on the input of date picker
		WebElement input_date_picker = driver.findElement(By.xpath("//input[@id='datepicker']"));
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='datepicker']"))).click();
		
		
		
		input_date_picker.click();		
		
		if (input_date_picker.isDisplayed() && input_date_picker.isEnabled()) {
			
			input_date_picker.click();
		} else {
		    System.out.println("Input box is not interactable.");
		}
		
		
		//input_date_picker.click();
		 		
		// Expected Date
		String required_year = "2025";
		String required_month = "May";
		String required_date = "10";
		
		selectDate(driver, required_year, required_month, required_date);
		
		
		
				
		driver.quit();
		
		// input I want to select 
		

	}

}
