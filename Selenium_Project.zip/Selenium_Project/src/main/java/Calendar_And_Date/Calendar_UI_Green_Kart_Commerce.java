package Calendar_And_Date;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Calendar_UI_Green_Kart_Commerce {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/seleniumPractise/#/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
												
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																	
		// Maximize Browser window
		driver.manage().window().maximize();
																	
		// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/offers
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		String month = "6";
		String date = "15";
		String year = "2025";
		
		String[] date_arr = {month, date, year};
		
		// Time delay
		Thread.sleep(5000);
		
//		driver.findElement(By.cssSelector("div.react-date-picker__inputGroup")).click();
//		
//		// Time delay
//		Thread.sleep(5000);
		
		
		WebElement date_picker_btn = driver.findElement(By.xpath("//button[@class='react-date-picker__calendar-button react-date-picker__button']"));
		date_picker_btn.click();
		
		// Time delay
		Thread.sleep(3000);
				
		WebElement calender_navigation = driver.findElement(By.xpath("//button[@class=\"react-calendar__navigation__label\"]"));
		calender_navigation.click();
		
		// Time delay
		Thread.sleep(3000);
		
		calender_navigation.click();
				
		// Time delay
		Thread.sleep(2000);
		
		WebElement select_year_btn = driver.findElement(By.xpath("//button[text()="+year+"]"));
		select_year_btn.click();
		
		// Time delay
		Thread.sleep(2000);
		
		//List<WebElement> month_list = driver.findElements(By.cssSelector("button.react-calendar__year-view__months__month"));
				
//		for(WebElement month_ele : month_list)
//		{
//			
//		}
		
		// Locate the month out of all 
		driver.findElements(By.cssSelector("button.react-calendar__year-view__months__month")).get(Integer.parseInt(month)-1).click();
		
		// Time delay
		Thread.sleep(2000);
		
		// Locate the date element using xpath : //abbr[text()='15']
		//abbr[text()='15']
		driver.findElement(By.xpath("//abbr[text()="+date+"]")).click();
		
		
		// To get the text locate element using xpath :  //input[contains(@class, 'react-date-picker__inputGroup__input')]
		List<WebElement> date_ele_list = driver.findElements(By.xpath("//input[contains(@class, 'react-date-picker__inputGroup__input')]"));
		
		for(WebElement date_ele : date_ele_list)
		{
			System.out.println(date_ele.getAttribute("value"));
			
		}
		
		// Verify that the date is exactly same as month = 6, date = 15, year = 2025
		for(int i=0 ; i < date_ele_list.size() ; i++)
		{
			System.out.println(date_ele_list.get(i).getAttribute("value"));
			Assert.assertEquals(date_ele_list.get(i).getAttribute("value"), date_arr[i]);
		}
		
		// Time delay
		Thread.sleep(10000);
				
		// close windows
		driver.quit();
		
	}

}
