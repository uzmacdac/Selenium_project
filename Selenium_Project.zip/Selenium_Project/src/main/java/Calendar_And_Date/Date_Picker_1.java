package Calendar_And_Date;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Date_Picker_1 {
	
	public static void selectFutureDate(WebDriver driver, String expected_year, String expected_month, String expected_date ) throws InterruptedException {
		
		//  Select Month and Year
		while(true)
		{
			String date_picker_current_month = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
			
			String date_picker_current_year = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
			
			// Check the expected month and year are matching or not with current month and year
			if(date_picker_current_month.equals( expected_month) && date_picker_current_year.equals( expected_year))
			{
				break;
			}
			
			// Time Delay
			Thread.sleep(1000);
			
			// if the month is not matching to the expected month click on the next icon 
			WebElement date_picker_next_month = driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']"));
			date_picker_next_month.click();
		}
		
		// Locating Calender Elements using xpath : //table[@class='ui-datepicker-calendar']//tbody//tr
		// xpath : //table[@class='ui-datepicker-calendar']//tbody//tr/td
		//List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr"));
				
		List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td"));
						
		// traverse the list
		for(WebElement calender_date : calender_all_dates)
		{
			// Check the date is matches to the expected date if matches then click on it
			if(calender_date.getText().equals(expected_date))
			{
				// Click on the date 
				calender_date.click();
								
				break;
			}
		}
		
		
		
	}
	
	public static void selectPastDate(WebDriver driver, String expected_year, String expected_month, String expected_date ) throws InterruptedException {
		
		// Click on the previous button using xpath : //span[@class='ui-icon ui-icon-circle-triangle-w']
		
	//  Select Month and Year
			while(true)
			{
				String date_picker_current_month = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
				
				String date_picker_current_year = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
				
				// Check the expected month and year are matching or not with current month and year
				if(date_picker_current_month.equals( expected_month) && date_picker_current_year.equals( expected_year))
				{
					break;
				}
				
				// Time Delay
				Thread.sleep(1000);
				
				// if the month is not matching to the expected month click on the next icon 
				WebElement date_picker_prevoious_month = driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']"));
				date_picker_prevoious_month.click();
			}
			
			// Locating Calender Elements using xpath : //table[@class='ui-datepicker-calendar']//tbody//tr
			// xpath : //table[@class='ui-datepicker-calendar']//tbody//tr/td
			//List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr"));
					
			List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td"));
							
			// traverse the list
			for(WebElement calender_date : calender_all_dates)
			{
				// Check the date is matches to the expected date if matches then click on it
				if(calender_date.getText().equals(expected_date))
				{
					// Click on the date 
					calender_date.click();
									
					break;
				}
			}
		
	}
	
	public static void selectDate(WebDriver driver, String expected_date) {
		
		// Locating Calender Elements using xpath : //table[@class='ui-datepicker-calendar']//tbody//tr
		// xpath : //table[@class='ui-datepicker-calendar']//tbody//tr/td
		//List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr"));
		
		List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td"));
				
		// traverse the list
		for(WebElement calender_date : calender_all_dates)
		{
			// Check the date is matches to the expected date if matches then click on it
			if(calender_date.getText().equals(expected_date))
			{
				// Click on the date 
				calender_date.click();
						
				break;
			}
		}
		
	}
	
	

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Driver
		WebDriver driver = new ChromeDriver();
		
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://jqueryui.com/datepicker/
		driver.get("https://jqueryui.com/datepicker/");
		
		// date picker is inside iframe, so we have to switch to iframe
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		
		// Click on the input locate the element using the xpath : //p//input[@id='datepicker']
		WebElement date_input = driver.findElement(By.xpath("//p//input[@id='datepicker']"));
		date_input.click();
		
		//--------------------------------------------------------------------
		
		// Method - 1 : Using the sendKeys()
		//date_picker.sendKeys("10/14/2024");
		
		//----------------------------------------------------------------------
		
		// Method - 2 : Using the Date Picker
		
		// Expected Date
		String expected_year = "2025";
		String expected_month = "May";
		String expected_date = "10";
		
		//  Select Future Date
		selectFutureDate(driver, expected_year, expected_month, expected_date );
		
		
		// Time Delay
		Thread.sleep(5000);
		
		// Click again to set past date
		date_input.click();
		
		// Expected Date
		expected_year = "2023";
		expected_month = "July";
		expected_date = "5";
		
		
		//  Select Past Date
		selectPastDate(driver, expected_year, expected_month, expected_date );
		
		//WebElement date_picker_previous_month = driver.findElement(By.xpath("//a[@class='ui-datepicker-prev ui-corner-all ui-state-hover ui-datepicker-prev-hover']"));
		//date_picker_previous_month.click();
		
		// Select Date
		//selectDate(driver, expected_date);
		
		
		
	}

}



/*
 
 
public class Date_Picker_1 {
	
	public static void selectMonthAndYear(WebDriver driver, String expected_year, String expected_month ) throws InterruptedException {
		
		//  Select Month and Year
		while(true)
		{
			String date_picker_current_month = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
			
			String date_picker_current_year = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
			
			// Check the expected month and year are matching or not with current month and year
			if(date_picker_current_month.equals( expected_month) && date_picker_current_year.equals( expected_year))
			{
				break;
			}
			
			// Time Delay
			Thread.sleep(1000);
			
			// if the month is not matching to the expected month click on the next icon 
			WebElement date_picker_next_month = driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']"));
			date_picker_next_month.click();
		}
		
	}
	
	public static void selectDate(WebDriver driver, String expected_date) {
		
		// Locating Calender Elements using xpath : //table[@class='ui-datepicker-calendar']//tbody//tr
		// xpath : //table[@class='ui-datepicker-calendar']//tbody//tr/td
		//List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr"));
		
		List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td"));
				
		// traverse the list
		for(WebElement calender_date : calender_all_dates)
		{
			// Check the date is matches to the expected date if matches then click on it
			if(calender_date.getText().equals(expected_date))
			{
				// Click on the date 
				calender_date.click();
						
				break;
			}
		}
		
	}
	
	

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Driver
		WebDriver driver = new ChromeDriver();
		
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://jqueryui.com/datepicker/
		driver.get("https://jqueryui.com/datepicker/");
		
		// date picker is inside iframe, so we have to switch to iframe
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		
		// Click on the input locate the element using the xpath : //p//input[@id='datepicker']
		WebElement date_input = driver.findElement(By.xpath("//p//input[@id='datepicker']"));
		date_input.click();
		
		//--------------------------------------------------------------------
		
		// Method - 1 : Using the sendKeys()
		//date_picker.sendKeys("10/14/2024");
		
		//----------------------------------------------------------------------
		
		// Method - 2 : Using the Date Picker
		
		// Expected Date
		String expected_year = "2025";
		String expected_month = "May";
		String expected_date = "10";
		
		//  Select Month and Year
		selectMonthAndYear(driver, expected_year, expected_month );
		
		
		
		//WebElement date_picker_previous_month = driver.findElement(By.xpath("//a[@class='ui-datepicker-prev ui-corner-all ui-state-hover ui-datepicker-prev-hover']"));
		//date_picker_previous_month.click();
		
		// Select Date
		selectDate(driver, expected_date);
	}

}
 
 */


/*

public class Date_Picker {
	
	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Driver
		WebDriver driver = new ChromeDriver();
		
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://jqueryui.com/datepicker/
		driver.get("https://jqueryui.com/datepicker/");
		
		// date picker is inside iframe, so we have to switch to iframe
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		
		// Click on the input locate the element using the xpath : //p//input[@id='datepicker']
		WebElement date_input = driver.findElement(By.xpath("//p//input[@id='datepicker']"));
		date_input.click();
		
		//--------------------------------------------------------------------
		
		// Method - 1 : Using the sendKeys()
		//date_picker.sendKeys("10/14/2024");
		
		//----------------------------------------------------------------------
		
		// Method - 2 : Using the Date Picker
		
		// Expected Date
		String expected_year = "2025";
		String expected_month = "May";
		String expected_date = "10";
		
		//  Select Month and Year
		while(true)
		{
			String date_picker_current_month = driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
			
			String date_picker_current_year = driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
			
			// Check the expected month and year are matching or not with current month and year
			if(date_picker_current_month.equals( expected_month) && date_picker_current_year.equals( expected_year))
			{
				break;
			}
			
			// Time Delay
			Thread.sleep(1000);
			
			// if the month is not matching to the expected month click on the next icon 
			WebElement date_picker_next_month = driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']"));
			date_picker_next_month.click();
		}
		
		
		
		//WebElement date_picker_previous_month = driver.findElement(By.xpath("//a[@class='ui-datepicker-prev ui-corner-all ui-state-hover ui-datepicker-prev-hover']"));
		//date_picker_previous_month.click();
		
		// Locating Calender Elements using xpath : //table[@class='ui-datepicker-calendar']//tbody//tr
		List<WebElement> calender_all_dates = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr"));
		
		// traverse the list
		for(WebElement calender_date : calender_all_dates)
		{
			// Check the date is matches to the expected date if matches then click on it
			if(calender_date.getText().equals(expected_date))
			{
				// Click on the date 
				calender_date.click();
				
				break;
			}
		}
	}

}



*/