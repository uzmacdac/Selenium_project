package Chrome_Options;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Enable_Extension_At_Run_Time {

	// 1. Add CRX Extractor/Downloader to Chrome browser - manually
	// 2. Add extension (here I have added SelectorHub extension to chrome browser) to the Chrome browser - manually
	// 3. capture the crx file for extension (here selectorHub crx file by going to the web page from the extension you have downloaded right click on it 
	//    you will get the option to download it and save it on your folder
	// 4. create file object and pass the path where you have store the crx file 
	// 5. Pass the crx file to the automation script in chrome 
	
	
	public static void main(String[] args) throws InterruptedException {
		
		// Create ChromeOptions object to configure ChromeDriver
		ChromeOptions option = new ChromeOptions();
			
		// D:\Selenium_Java\CRX_extension
		File select_hub_crx = new File("D:\\Selenium_Java\\CRX_extension\\SelectorsHub-XPath-Helper-Chrome-Web-Store.crx");
		// Adding extension
		option.addExtensions(select_hub_crx);
		

		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(option);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://text-compare.com/
		driver.get("https://text-compare.com/");	
		
		
		String title = driver.getTitle();
		System.out.println("Title : "+title);
		
		if(title.equals("Text Compare! - Find differences between two text files"))
		{
			System.out.println("Test Case Passed.");
		}
		else
		{
			System.out.println("Test Case Failed.");
		}

		

	
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
	}

}
