package Chrome_Options;

import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v126.network.Network;

public class Authentication_Popups {

	// 1. Using Chrome DevTools Protocal CDP
	// http://username:password@example.com
	
	public static void main(String[] args) {
		
		// create ChromeOptions instance 
		ChromeOptions options = new ChromeOptions();
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
		
		DevTools devTools = ((ChromeDriver)driver).getDevTools();
		
		// Create session
		devTools.createSession();
		
		// Set up Basic Authentication credentials
        String username = "admin";
        String password = "admin";
		
		// Send 
		devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
		
		// Send the username and password
		//devTools.send(Network.setAuthCredentials("the-internet.herokuapp.com/basic_auth", username, password, Optional.empty()));
															
		// Open url : https://the-internet.herokuapp.com/basic_auth
		// https://admin:admin@the-internet.herokuapp.com/basic_auth
		driver.get(" https://admin:admin@the-internet.herokuapp.com/basic_auth");
		

	}

}

/*
  
public class Authentication_Popups {

	// 1. Using the Browser Capabliities
	// http://username:password@example.com
	
	public static void main(String[] args) {
		
		// create ChromeOptions instance 
		ChromeOptions options = new ChromeOptions();
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
		
		// Set the Desired Capabilities
		options.addArguments("--disable-popup-blocking");
															
		// Open url : https://the-internet.herokuapp.com/basic_auth
		// https://admin:admin@the-internet.herokuapp.com/basic_auth
		driver.get(" https://admin:admin@the-internet.herokuapp.com/basic_auth");
		

	}

}  
 
 */


/*
 
public class Authentication_Popups {

	// 1. Using the Browser Capabliities
	// http://username:password@example.com
	
	public static void main(String[] args) {
		
		// create ChromeOptions instance 
		ChromeOptions options = new ChromeOptions();
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
		
		// Set the Desired Capabilities
		options.addArguments("--disable-blink-features=AutomationControlled");
															
		// Open url : https://the-internet.herokuapp.com/basic_auth
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
		

	}

}  
 
 */



/*

public class Authentication_Popups {

	// 1. Using the embedded credentials 
	// http://username:password@example.com
	
	public static void main(String[] args) {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://the-internet.herokuapp.com/basic_auth
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
		

	}

}


*/