package Chrome_Options;

import java.net.HttpURLConnection;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Headless_Testing {

	public static void main(String[] args) throws InterruptedException {
		
		// Create ChromeOptions object to configure ChromeDriver
		ChromeOptions option = new ChromeOptions();
		
		// Headless mode : In headless mode, the browser can still perform actions like navigating to URLs, filling forms, 
		// interacting with elements, and running JavaScript, but it does all of this in the background without displaying the window.
		
		// Add argument to run Chrome in headless mode  
		// Launch Chrome in headless mode
		//option.addArguments("--headless=new");
		option.addArguments("--headless");
		
		// Set headless mode using the setHeadless() method
        //options.setHeadless(true);  // Correct method in Selenium 4.x		

		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(option);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://demo.opencart.com/
		driver.get("https://demo.opencart.com/");	
		
		
		String title = driver.getTitle();
		
		if(title.equals("Your Store"))
		{
			System.out.println("Test Case Passed.");
		}
		else
		{
			System.out.println("Test Case Failed.");
		}

		

	
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
		

	}

}
