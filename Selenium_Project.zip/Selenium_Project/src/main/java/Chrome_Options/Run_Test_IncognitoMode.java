package Chrome_Options;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Run_Test_IncognitoMode {

	public static void main(String[] args) throws InterruptedException {
		
		// Create ChromeOptions object to configure ChromeDriver
		ChromeOptions option = new ChromeOptions();
			
		// Not saving history and cookies by launching browser in incognito mode
		option.addArguments("--incognito");
		
//		List<String> switches = new ArrayList<>();
//		switches.add("enable-automation");
//		options.setExperimentalOption("excludeSwitches", switches);
		

		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(option);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://demo.opencart.com/
		driver.get("https://demo.opencart.com/");	
		
		
		String title = driver.getTitle();
		
		if(title.equals("Your Store"))
		{
			System.out.println("Test Case Passed.");
		}
		else
		{
			System.out.println("Test Case Failed.");
		}

		

	
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
	}

}
