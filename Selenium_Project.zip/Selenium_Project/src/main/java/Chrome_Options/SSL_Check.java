package Chrome_Options;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class SSL_Check {

	public static void main(String[] args) throws InterruptedException {
	
			// https://expired.badssl.com/				
			
			// Create ChromeOptions class object
			ChromeOptions options = new ChromeOptions();
			
			// set non https website to browse- This will let you go to non https website without any hurdle
			options.setAcceptInsecureCerts(true);
			
			// Launch Chrome Browser
			WebDriver driver = new ChromeDriver(options);
			
			// Javascript  
			JavascriptExecutor js = (JavascriptExecutor) driver;
			
			// Maximize Browser window
			driver.manage().window().maximize();
																							
			// Open url :  https://expired.badssl.com/
			driver.get("https://expired.badssl.com/");	
			
			System.out.println("Title : "+driver.getTitle());

			// Time delay
			Thread.sleep(5000);
			
			// close 
			driver.quit();
		
	}

}


/*
 
  
import java.util.HashMap;

import java.util.Map;



import org.openqa.selenium.Proxy;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.edge.EdgeOptions;

import org.openqa.selenium.firefox.FirefoxOptions;



public class SSLCheck {



public static void main(String[] args) {

// TODO Auto-generated method stub

ChromeOptions options = new ChromeOptions();

Proxy proxy = new Proxy();

proxy.setHttpProxy("ipaddress:4444");

options.setCapability("proxy", proxy);

Map<String, Object> prefs = new HashMap<String, Object>();



prefs.put("download.default_directory", "/directory/path");



options.setExperimentalOption("prefs", prefs);

// FirefoxOptions options1 = new FirefoxOptions();

// options1.setAcceptInsecureCerts(true);

// EdgeOptions options2 = new EdgeOptions();

options.setAcceptInsecureCerts(true);

System.setProperty("webdriver.chrome.driver", "/Users/rahulshetty/Documents/chromedriver");



WebDriver driver = new ChromeDriver(options);

driver.get("https://expired.badssl.com/");

System.out.println(driver.getTitle());



}



} 
 
 
 
 */
