package Window_Handling;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Invoking_Multiple_Window_Or_Tab_ScreenShot {
	
	//  https://rahulshettyacademy.com/angularpractice/
	
	// Requirement : Invoking Multiple Windows/Tabs from Selenium using one driver instance
	// Scenario  : Navigate to the https://rahulshettyacademy.com/angularpractice/
	// fill the "Name" field with the first course name available at  https://rahulshettyacademy.com
	
	// Capture Screenshot for only the name web element 
	
	// Check the height and width of the editbox or textbox
	

	public static void main(String[] args) throws IOException, InterruptedException {
		
		
		// Launch Chrome driver		
				WebDriver driver = new ChromeDriver();		
				
				// Explicit wait 
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
							
				// Maximize Browser window
				driver.manage().window().maximize();
											
				// Open url : https://rahulshettyacademy.com/angularpractice/
				driver.get("https://rahulshettyacademy.com/angularpractice/");
				
				// switch to new tab
				driver.switchTo().newWindow(WindowType.TAB);
				
				// get the Window id using getWindowHandles
				Set<String> windows_handles_ids = driver.getWindowHandles();
				
				// Reference of the Iterator interface 
				Iterator<String> itr = windows_handles_ids.iterator();
				
				// parent window handle
				String parent_window_id = itr.next();
				
				// child window handle
				String child_wimdow_id = itr.next();
				
				
				// go the child window
				driver.switchTo().window(child_wimdow_id);
				
				// Open url : https://courses.rahulshettyacademy.com/courses
				driver.get("https://courses.rahulshettyacademy.com/courses");
				
				
				// Here the courses changes every time 
				// to get the core jave course we need to use partial link text
				// Getting course titile using partial link 
				
				// capture the all element of courses
				List<WebElement> courses = driver.findElements(By.cssSelector("div[data-course-url*='/p']"));
				
				String course_name = "";
				
				for(WebElement course : courses)
				{
					System.out.println("Course Title  : "+course.getText());
				}
				
				
				for(WebElement course : courses)
				{
					if(course.getText().contains("Core Java for Automation"))
					{
						course_name = course.getText();
						break;
					}
				}
				
				// switching to the https://rahulshettyacademy.com/angularpractice/
				driver.switchTo().window(parent_window_id);
				
				// fill name input captured from  https://courses.rahulshettyacademy.com/courses  coursed website 
				// //input[@name='name' and @class='form-control ng-pristine ng-invalid ng-touched']
				// wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='name' and @class='form-control ng-pristine ng-invalid ng-touched']")));
				
				// delay time
				Thread.sleep(5000);
				 
				WebElement name = driver.findElement(By.xpath("//input[@name='name' and contains(@class, 'form-control')]"));

				
				name.sendKeys(course_name);
				
				// Capturing the name web element 
				File file = name.getScreenshotAs(OutputType.FILE);
				
				// save in destination 
				FileUtils.copyFile(file, new File("D:\\Selenium_Java\\ScreenShots\\course_name.png"));
				
				// Get the Height and Width of the editbox and textbox
				System.out.println("Height of the Editbox : "+name.getRect().getDimension().getHeight());
				
				System.out.println("Width of the Editbox : "+name.getRect().getDimension().getWidth());
				
				
				
				// Time delay
				Thread.sleep(5000);
									
				// close 
				driver.quit();
				

	}

}
