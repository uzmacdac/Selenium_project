package Window_Handling;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class Window_Handling {
	
	// https://www.opencart.com/index.php?route=cms/demo
	// https://opensource-demo.orangehrmlive.com/web/index.php/auth/login

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																		
		// Maximize Browser window
		driver.manage().window().maximize();
		
		// Requirement is that a window open with https://www.opencart.com/index.php?route=cms/demo
		// and then new window open with https://opensource-demo.orangehrmlive.com/web/index.php/auth/login also with the focus
														
		// https://www.opencart.com/index.php?route=cms/demo
		driver.get("https://www.opencart.com/index.php?route=cms/demo");
		
		// https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
		
		// selenium 4 onward this is inroduce 
		// This will open new tab in the browser and switch the focus to new tab
		//driver.switchTo().newWindow(WindowType.TAB);
		
		// This will new browser window and switch the focus to new browser window
		driver.switchTo().newWindow(WindowType.WINDOW);
		
		
		// https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();
			
	}

}
