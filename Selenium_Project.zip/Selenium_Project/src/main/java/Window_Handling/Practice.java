package Window_Handling;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Practice {

	public static void main(String[] args) {
	
		// Launch Chrome driver		
				WebDriver driver = new ChromeDriver();		
				
				// Explicit wait 
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
							
				// Maximize Browser window
				driver.manage().window().maximize();
											
				// Open url : https://rahulshettyacademy.com/angularpractice/
				driver.get("https://rahulshettyacademy.com/angularpractice/");
				
				WebElement name = driver.findElement(By.xpath("//input[@name='name' and contains(@class, 'form-control')]"));

				name.sendKeys("core");

		
	}

}
