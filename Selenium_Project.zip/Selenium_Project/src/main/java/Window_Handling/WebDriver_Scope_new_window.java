package Window_Handling;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriver_Scope_new_window {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
							
		// 
		// Open url : https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		System.out.println("Totaol link : "+ driver.findElements(By.tagName("a")).size());
		
		// Locate footer element using xpath : //div[@id='gf-BIG' and @class=' footer_top_agile_w3ls gffoot footer_style']
		WebElement footer_driver = driver.findElement(By.id("gf-BIG"));
		
		// Limiting the scope 
		System.out.println("Total Link in Footer Section : "+footer_driver.findElements(By.tagName("a")).size());
		
		// Locate coloumn element of the footer section using xpath : //table[@class='gf-t']//tbody//tr//td[1]
		WebElement coloumn_driver = driver.findElement(By.xpath("//table[@class='gf-t']//tbody//tr//td[1]//ul"));
		// Total link count
		System.out.println("Total Column Size : "+ coloumn_driver.findElements(By.tagName("a")).size());
		
		// Click on the each link in the coloum and check if the pagee are opening or not 
		// iterate over the list of the link element
		for(int i=0 ; i < coloumn_driver.findElements(By.tagName("a")).size() ; i++ )
		{
			
			// for trying to click on the other link it will throw the StaleReferenceElementException
			// because for the first time you click on the link it will open the page on the same tab not in other tab 
			// then you are trying to click on the other link but you already navigate to first link that's why it throw exception
			// to avoid this situation we know that to open the link in new tab we have to press the ctrl key and hold on to it then click on
			// the link it will open in the new tab
			
			String click_on_new_tab = Keys.chord(Keys.CONTROL, Keys.ENTER);
			coloumn_driver.findElements(By.tagName("a")).get(i).sendKeys(click_on_new_tab);
			
			// get the text 
			System.out.println(i+") "+coloumn_driver.findElements(By.tagName("a")).get(i).getText());
			
			// Time delay
			Thread.sleep(5000);
			
			
			
		}
		
		// get the window handle 
		Set<String> window = driver.getWindowHandles();
					
		// Iterator -> 
		Iterator<String> itr = window.iterator();
					
		// it traverse through the window set if the next element is present 
		while(itr.hasNext())
		{
			// switch to window 
			driver.switchTo().window(itr.next());
						
			// Print the title
			System.out.println("Title : "+ driver.getTitle());
		}
		
		
		
				
		// Time delay
		Thread.sleep(5000);
		
		driver.quit();
		
	}

}


/*

public class WebDriver_Scope_new_window {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
							
		// 
		// Open url : https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		System.out.println("Totaol link : "+ driver.findElements(By.tagName("a")).size());
		
		// Locate footer element using xpath : //div[@id='gf-BIG' and @class=' footer_top_agile_w3ls gffoot footer_style']
		WebElement footer_driver = driver.findElement(By.id("gf-BIG"));
		
		// Limiting the scope 
		System.out.println("Total Link in Footer Section : "+footer_driver.findElements(By.tagName("a")).size());
		
		// Locate coloumn element of the footer section using xpath : //table[@class='gf-t']//tbody//tr//td[1]
		WebElement coloumn_driver = driver.findElement(By.xpath("//table[@class='gf-t']//tbody//tr//td[1]//ul"));
		// Total link count
		System.out.println("Total Column Size : "+ coloumn_driver.findElements(By.tagName("a")).size());
		
		// Click on the each link in the coloum and check if the pagee are opening or not 
		// iterate over the list of the link element
		for(int i=0 ; i < coloumn_driver.findElements(By.tagName("a")).size() ; i++ )
		{
			
			// Retrieving the element and click
			coloumn_driver.findElements(By.tagName("a")).get(i).click();
			System.out.println(i+") "+coloumn_driver.findElements(By.tagName("a")).get(i).getText());
			
			// for trying to click on the other link it will throw the StaleReferenceElementException
			// because for the first time you click on the link it will open the page on the same tab not in other tab 
			// then you are trying to click on the other link but you already navigate to first link that's why it throw exception
			// to avoid this situation we know that to open the link in new tab we have to press the ctrl key and hold on to it then click on
			// the link it will open in the new tab
		}
		
				
		// Time delay
		Thread.sleep(5000);
		
		driver.quit();
		
	}

}



*/