package Window_Handling;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Scrolling_Table_Window {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
														
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																			
		// Maximize Browser window
		driver.manage().window().maximize();
																			
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
								
		// Scroll to Web Table Fix Header
		// Scroll the window or browser to 500
		js.executeScript("window.scrollBy(0, 500)");
		
		// Time delay
		Thread.sleep(2000);	
		
		// document.querySelector(".tableFixHead").scrollBy(0, 500)  -> Scroll the specific element
		js.executeScript("document.querySelector(\".tableFixHead\").scrollTop=5000");
				
		// Locate the element to fetch the last coloumn data
		List<WebElement> list_of_last_col_ele = driver.findElements(By.cssSelector(".tableFixHead td:nth-child(4)"));
		
		int sum = 0;
		
		// traverse through the element 
		for(int i=0 ; i < list_of_last_col_ele.size() ; i++)
		{
			sum += Integer.parseInt(list_of_last_col_ele.get(i).getText());
			//System.out.println(Integer.parseInt(list_of_last_col_ele.get(i).getText()));
		}
		
		System.out.println("Total Sum : "+sum);
		
		// css selector : div.totalAmount
		WebElement total_amount = driver.findElement(By.cssSelector("div.totalAmount"));
		String total_amount_txt = total_amount.getText();
		
		
		String amount = total_amount.getText().split(":")[1].trim();
		System.out.println("Amount : "+amount);
				
		// pattern - one or more digit 
		Pattern pattern = Pattern.compile("\\d+");
		
		// match the pattern in the string 
		Matcher matcher = pattern.matcher(total_amount_txt);
		int number = 0;
		if(matcher.find())
		{
			// 
			String number_in_str = matcher.group();
			number = Integer.parseInt(number_in_str);
			System.out.println(number);
		}
		
		// Verify that the total sum is 296 
		Assert.assertEquals(sum, number, "Test Passed : sum and number are equal ");
		
		// Time delay
		Thread.sleep(5000);
						
		// close windows
		driver.quit();
		

	}

}
