package Locator_And_Type;

public class XPath_Axes {

	public static void main(String[] args) {
		

	}

}
