package URL;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Broken_Url {

	public static void main(String[] args) throws InterruptedException, MalformedURLException, IOException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");	
		
		// Broken Link or URL 
		// Step- 1 : To get all urls tied up to the links using Selenium
		//           Java methods will call URLs and get the status code 
		// If the status code > 400 then the url is not working -> Link which tied to url is broken
		
		
		// Locate elemet using the cssSelector - a[href*='soapui']
		WebElement link = driver.findElement(By.cssSelector("a[href*='brokenlink']"));
		String url = link.getAttribute("href");
		System.out.println("Attribute : "+url);
		
		// Create the reference of the URLConnection
		HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
		conn.setRequestMethod("HEAD");
		conn.connect();
		
		// Get status code or response code
		int response_code = conn.getResponseCode();
		System.out.println("URL response code : "+response_code);
		
		
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
	}

}



/*

public class Broken_Url {

	public static void main(String[] args) throws InterruptedException, MalformedURLException, IOException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");	
		
		// Broken Link or URL 
		// Step- 1 : To get all urls tied up to the links using Selenium
		//           Java methods will call URLs and get the status code 
		// If the status code > 400 then the url is not working -> Link which tied to url is broken
		
		
		// Locate elemet using the cssSelector - a[href*='soapui']
		WebElement link = driver.findElement(By.cssSelector("a[href*='soapui']"));
		String url = link.getAttribute("href");
		System.out.println("Attribute : "+url);
		
		// Create the reference of the URLConnection
		HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
		conn.setRequestMethod("HEAD");
		conn.connect();
		
		// Get status code or response code
		int response_code = conn.getResponseCode();
		System.out.println("URL response code : "+response_code);
		
		
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
	}

}




*/