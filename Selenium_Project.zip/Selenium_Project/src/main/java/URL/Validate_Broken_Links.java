package URL;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class Validate_Broken_Links {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		

		// Broken Link or URL 
		// Step- 1 : To get all urls tied up to the links using Selenium
		//           Java methods will call URLs and get the status code 
		// If the status code > 400 then the url is not working -> Link which tied to url is broken
		
		
		// Locate elemet using the cssSelector - a[href*='soapui']
		
		// List of webelement of a 
		List<WebElement> links = driver.findElements(By.cssSelector("li[class='gf-li'] a:not(h3 a)"));
		
		// Create object of the SoftAssert 
		SoftAssert soft_assert = new SoftAssert();
		
		
		for(WebElement link : links)
		{
					
			String url = link.getAttribute("href");
			//System.out.println("Attribute : "+url);
			
			// Create the reference of the URLConnection
			HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setRequestMethod("HEAD");
			conn.connect();
			
			// Get status code or response code
			int response_code = conn.getResponseCode();
			//System.out.println("URL response code : "+response_code);
			System.out.println("The link with Text '" + link.getText() + "' and response the code " + response_code);
			
			//Assert.assertTrue(response_code < 400, "The link with Text '"+link.getText()+"' is broken with the code "+response_code);
			soft_assert.assertTrue(response_code < 400 || response_code == 403 , "The link with Text '"+link.getText()+"' is broken with the code "+response_code);
			
		}
		
		soft_assert.assertAll();
				
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();

	}

}



/*
  
public class Validate_Broken_Links {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		

		// Broken Link or URL 
		// Step- 1 : To get all urls tied up to the links using Selenium
		//           Java methods will call URLs and get the status code 
		// If the status code > 400 then the url is not working -> Link which tied to url is broken
		
		
		// Locate elemet using the cssSelector - a[href*='soapui']
		
		// List of webelement of a 
		List<WebElement> links = driver.findElements(By.cssSelector("li[class='gf-li'] a:not(h3 a)"));
		for(WebElement link : links)
		{
					
			String url = link.getAttribute("href");
			//System.out.println("Attribute : "+url);
			
			// Create the reference of the URLConnection
			HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setRequestMethod("HEAD");
			conn.connect();
			
			// Get status code or response code
			int response_code = conn.getResponseCode();
			//System.out.println("URL response code : "+response_code);
			System.out.println("The link with Text '" + link.getText() + "' and response the code " + response_code);
			
			//Assert.assertTrue(response_code < 400, "The link with Text '"+link.getText()+"' is broken with the code "+response_code);
			Assert.assertTrue(response_code < 400 || response_code == 403 , "The link with Text '"+link.getText()+"' is broken with the code "+response_code);
			
		}
		
				
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();

	}

} 
  
 
*/



/*

public class Validate_Broken_Links {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		

		// Broken Link or URL 
		// Step- 1 : To get all urls tied up to the links using Selenium
		//           Java methods will call URLs and get the status code 
		// If the status code > 400 then the url is not working -> Link which tied to url is broken
		
		
		// Locate elemet using the cssSelector - a[href*='soapui']
		
		// List of webelement of a 
		List<WebElement> links = driver.findElements(By.cssSelector("li[class='gf-li'] a"));
		for(WebElement link : links)
		{
					
			String url = link.getAttribute("href");
			//System.out.println("Attribute : "+url);
			
			// Create the reference of the URLConnection
			HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setRequestMethod("HEAD");
			conn.connect();
			
			// Get status code or response code
			int response_code = conn.getResponseCode();
			System.out.println("URL response code : "+response_code);
			
			// Validating the response code
			if(response_code > 400  && response_code != 403)
			{
				System.out.println("The link with Text '"+link.getText()+"' is broken with the code "+response_code);
				Assert.assertTrue(false);
			}
			else if (response_code == 403) 
			{
				 // Special handling for 403 Forbidden (if needed, can be logged)
				 System.out.println("The link with Text '" + link.getText() + "' is forbidden (403).");
			} 
			else 
			{
				// Handle success or other status codes like 200 (OK)
				System.out.println("The link with Text '" + link.getText() + "' is working fine with the code " + response_code);
			}
		}
		
				
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();

	}

}


*/