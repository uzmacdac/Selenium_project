package URL;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Broken_links_demo {

	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		// Create object of the ChromeOptions
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  http://www.deadlinkcity.com/
		driver.get("http://www.deadlinkcity.com/");	
		
		List<WebElement> links = driver.findElements(By.tagName("a"));
		
		System.out.println("Total No. of Links : "+links.size());
		
		int no_broken_links = 0;
		
		for(WebElement link : links)
		{
			String href_attribute_value = link.getAttribute("href");
			
			if(href_attribute_value == null || href_attribute_value.isEmpty() )
			{
				System.out.println("href attribute is null or empty. So it is not possible to check.");
				// skip this step 
				continue;
			}
			
			try
			{
				// hit url to the server
				// URL convert it to url 
				// Converted href value from String to url format
				URL link_url = new URL(href_attribute_value);
				
				// Create connection object 
				// Open connection to the server
				HttpURLConnection connection_url = (HttpURLConnection) link_url.openConnection();
				
				// Connect to the server and send the request to the server
				connection_url.connect();
				
				// After request is send get the response from the server
				// Response in the form of the status code 
				int response_code = connection_url.getResponseCode();
				if(response_code >= 400)
				{
					System.out.println(href_attribute_value+" =====> Link is Broken.");
					no_broken_links++;
				}
				else
				{
					System.out.println(href_attribute_value+" =====> Link is not broken.");
				}
			}
			catch(Exception e )
			{
				System.out.println("Error : "+e.getMessage());
			}
			
			
			
		}
		
		System.out.println("Number of Broken Links : "+no_broken_links);
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
	}

	
}
