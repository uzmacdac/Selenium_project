package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Frames_Drag_And_Drop {

	public static void main(String[] args) {
		
		// url open : https://jqueryui.com/droppable/

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://jqueryui.com/droppable/
		driver.get("https://jqueryui.com/droppable/");
		
		// web element for frame using xpath : //iframe[@class='demo-frame'] or using css Selector :
		//WebElement frame_ele = driver.findElement(By.xpath("//iframe[@class='demo-frame']"));
		WebElement frame_ele = driver.findElement(By.cssSelector("iframe[class='demo-frame']"));
		
		// switch to frame
		driver.switchTo().frame(frame_ele);
		
		// draggable element
		//WebElement draggable_ele = driver.findElement(By.id("draggable"));
		//draggable_ele.click();
		
		// action
		Actions action = new Actions(driver);
		
		// drag from the source
		WebElement source = driver.findElement(By.id("draggable"));
		
		// drop at the target
		WebElement target = driver.findElement(By.id("droppable"));
		
		action.dragAndDrop(source, target).build().perform();
		
		// switch back to original 
		driver.switchTo().defaultContent();
		

	}

}



/*

public class Frames {

	public static void main(String[] args) {
		
		// url open : https://jqueryui.com/droppable/

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://jqueryui.com/droppable/
		driver.get("https://jqueryui.com/droppable/");
		
		// web element for frame using xpath : //iframe[@class='demo-frame'] or using css Selector :
		//WebElement frame_ele = driver.findElement(By.xpath("//iframe[@class='demo-frame']"));
		WebElement frame_ele = driver.findElement(By.cssSelector("iframe[class='demo-frame']"));
		
		// switch to frame
		driver.switchTo().frame(frame_ele);
		
		// draggable element
		//WebElement draggable_ele = driver.findElement(By.id("draggable"));
		//draggable_ele.click();
		
		// action
		Actions action = new Actions(driver);
		
		// drag from the source
		WebElement source = driver.findElement(By.id("draggable"));
		
		// drop at the target
		WebElement target = driver.findElement(By.id("droppable"));
		
		action.dragAndDrop(source, target).build().perform();
		
		// switch back to original 
		driver.switchTo().defaultContent();
		

	}

}

*/