package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actions_Keyboard_Slider {
	// https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/
	// https://text-compare.com/
	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
															
		// Maximize Browser window
		driver.manage().window().maximize();
											
		// https://text-compare.com/
		driver.get("https://text-compare.com/");
		
		// Create the object of the Actions class
		Actions action = new Actions(driver);
		
		// Locate the text Area 1 element using xpath : //textarea[@id='inputText1']
		WebElement txt_area_1 = driver.findElement(By.xpath("//textarea[@id='inputText1']"));
		// send text
		txt_area_1.sendKeys("Welcome To Automation Testing");
		
		// Actions
		// Pressing any key use - KeyDown() method
		// For pressing any character use sendKeys(character)
		// ctrl + A - Select all text
		action.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
		
		// Ctrl + C - Copy the text into clipboard
		 action.keyDown(Keys.CONTROL).sendKeys("C").keyUp(Keys.CONTROL).perform();
		
		// tab - Shift to the second box(second text area) 
		action.keyDown(Keys.TAB).perform();
		
		// Ctrl + V - Paste the copied text 
		action.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).perform();
		
		
		
		// ctrl+shift+A - pressing the in order but while releasing the keys you have to go in reverse order
		// in this example - keys press in this order 
		//1. ctrl  2. shift
		// Keys release in this order
		// 1. shift  2. ctrl
		//action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys("A").keyUp(Keys.SHIFT).keyUp(Keys.CONTROL).perform();
				
		
		Thread.sleep(5000);
		driver.quit();
		
	}

}


/*

public class Actions_Keyboard_Slider {
	// https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
															
		// Maximize Browser window
		driver.manage().window().maximize();
											
		// https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/	
		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		
		// Create the object of the Actions class
		Actions action = new Actions(driver);
		
		// min slider starting point using xpath : //div[@id='slider-range']//span[1]
		WebElement min_slider = driver.findElement(By.xpath("//div[@id='slider-range']//span[1]"));
		
		// get the location of the minimum slider 
		Point min_slider_location = min_slider.getLocation();
		
		// (59, 288)
		System.out.println("Default location of the minimum slider : "+min_slider_location);
		
		// Drag the slider 
		action.dragAndDropBy(min_slider, 100, 288).perform();
		
		// min slider the 
		System.out.println("Get the location of the minimum slider after sliding : "+min_slider.getLocation());
		
		// Maximum slider,  locate the maximum slider element using the xpath : //div[@id='slider-range']//span[2]
		WebElement max_slider = driver.findElement(By.xpath("//div[@id='slider-range']//span[2]"));
		
		// get the location of the maximum slider - (612, 288)
		Point max_slider_location = max_slider.getLocation();
		
		// (612, 288)
		System.out.println("Default Maximum location : "+max_slider_location);
		
		// - minus sign we have to give to see the result
		action.dragAndDropBy(max_slider, -300, 288).perform();
		
		Thread.sleep(5000);
		driver.quit();
		
	}

}



*/