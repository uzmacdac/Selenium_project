package Actions;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Auto_suggest_dropdown_Using_Actions {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																					
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
		
		// click on auto suggest dropdown 
		WebElement auto_dropdow = driver.findElement(By.cssSelector("input#autocomplete"));
		auto_dropdow.click();
		
		auto_dropdow.sendKeys("ind");

		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);

		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);
		 
		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);

		System.out.println(driver.findElement(By.id("autocomplete")).getAttribute("value")); 


		
		
		
		
		// Time delay
		Thread.sleep(5000);
										
		// close windows
		driver.quit();
	}

	
}
