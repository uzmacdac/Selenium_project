package Actions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actions_Ajax_Mouse_Windows {
	
	// For practise : 
	// https://techblog.polteq.com/en/perform-a-sequence-of-actions-with-selenium-webdriver/
	// https://rahulshettyacademy.com/loginpagePractise/

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
									
		// Maximize Browser window
		driver.manage().window().maximize();
					
		// amazon url
		// Open url : https://rahulshettyacademy.com/loginpagePractise/
		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		
		// click on the linke using the xpath : //a[@class='blinkingText']   using css selector : a.blinkingText
		WebElement link = driver.findElement(By.cssSelector("a.blinkingText"));
		link.click();
		
		// get all windows handle [parentid, childid]
		Set<String> windows = driver.getWindowHandles();     
		
		// traverse through the set element [parentid, childid]
		Iterator<String> itr = windows.iterator();
		
		// Storing parentid : By doing  itr.next() control goes to first element 
		String parenId = itr.next();
		
		// Storing childid : we have to traver again itr.next()
		String childId = itr.next();
		
		// Switching driver to child window
		driver.switchTo().window(childId);
		
		//WebElement email_msg = driver.findElement(By.xpath("//p[@class='im-para red']//strong//a"));
		//String email = email_msg.getText();
		//System.out.println("Email : "+email);
		
		WebElement email_ele = driver.findElement(By.xpath("//p[@class='im-para red']"));
		String email_msg = email_ele.getText();
		System.out.println("Email msg : "+email_msg);
		
		// splitting the text in a such way that only get mentor@rahulshettyacademy.com
		// first split by at : it will give array of String containing {"Please email us at", " mentor@rahulshettyacademy.com with below template to receive response"}
		String[] arr_string = email_msg.split("at");
		
		// arr_string[0] = "Please email us at" and 
		// arr_string[1] = " mentor@rahulshettyacademy.com with below template to receive response"
		String email_string = arr_string[1].trim();
		
		// split email_string by whitespaces " "  give array of String
		// {"mentor@rahulshettyacademy.com", "with", "below", "template", "to", "receive", "response"}
		// store the email id by email_string[0] = "mentor@rahulshettyacademy.com";
		String email = email_string.split(" ")[0];
		System.out.println("Email : "+email);
		
		String email_id = driver.findElement(By.xpath("//p[@class='im-para red']")).getText().split("at")[1].trim().split(" ")[0];
		System.out.println("Email id : "+email_id);
		
		// Time delay
		Thread.sleep(3000);
		// Currently the focus on the child window
		// We have to switch back to the parent window
		driver.switchTo().window(parenId);
		
		// Locating the username input using css Selector : input#username
		WebElement username = driver.findElement(By.cssSelector("input#username"));
		username.sendKeys(email_id);
		
		
		
		

	}

}


/*

public class Actions_Ajax_Mouse_Windows {
	
	// For practise : 
	// https://techblog.polteq.com/en/perform-a-sequence-of-actions-with-selenium-webdriver/
	// https://rahulshettyacademy.com/loginpagePractise/

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
									
		// Maximize Browser window
		driver.manage().window().maximize();
					
		// amazon url
		// Open url : https://shorturl.at/7ZDal
		driver.get("https://shorturl.at/7ZDal");
		
		// Actions class instance
		Actions action = new Actions(driver);
		
		// Moves to specific element
		WebElement move = driver.findElement(By.cssSelector("a[id='nav-link-accountList']"));
		// using xpath : //*[@id='nav-link-accountList']
		// or use css Selector : a[id='nav-link-accountList']
		action.moveToElement(move).build().perform();
		
		// Right click on the element 
		// contextClick() is used to right click on the element
		action.moveToElement(move).contextClick().build().perform();
		
		// Time Delay
		Thread.sleep(3000);
		
		// We have to write in capital letter, for this scenario we used to press the shift key and then enter the alphabet key
		// move to search textbox
		// to do so first we have to click on the search textbox and then press the shift key and then enter letter
		// it is just entering the text in capital letter, it is not selecting the entered text for this action we 
		// have to double click on it 
//		WebElement move_to_searchTextBox = driver.findElement(By.id("twotabsearchtextbox"));
//		action.moveToElement(move_to_searchTextBox)
//		.click()
//		.keyDown(Keys.SHIFT)
//		.sendKeys("jeans and tops for women")
//		.build()
//		.perform();
		
		// now to select the enter item we have to double click on it 
		WebElement move_to_searchTextBox = driver.findElement(By.id("twotabsearchtextbox"));
		action.moveToElement(move_to_searchTextBox)
		.click()
		.keyDown(Keys.SHIFT)
		.sendKeys("jeans and tops for women")
		.doubleClick()
		.build()
		.perform();
		

	}

}

*/