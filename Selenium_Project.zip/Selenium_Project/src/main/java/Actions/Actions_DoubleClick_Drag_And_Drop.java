package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actions_DoubleClick_Drag_And_Drop {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
													
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// https: http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html	
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
				
		Thread.sleep(3000);
		
		// Create Actions class object
		Actions action = new Actions(driver);
		
		// drag rome box to italy box
		WebElement rome = driver.findElement(By.xpath("//div[@class='dragableBox' and @id='box6']"));
		
		// drop rome box to italy box
		WebElement italy = driver.findElement(By.xpath("//div[@class='dragableBoxRight' and @id='box106']"));
		
		// Perform action of dragging the rome box to italy box
		action.dragAndDrop(rome, italy).perform();
		
		// Time delay
		Thread.sleep(5000);
		
		// close session
		driver.quit();

	}

}


/*
 
public class Actions_DoubleClick_Drag_And_Drop {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
													
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_ev_ondblclick3	
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_ev_ondblclick3");
		
		// switch to iframe 
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='iframeResult']")));
		
		Thread.sleep(3000);
		
		WebElement field_1 = driver.findElement(By.xpath("//input[@id='field1']"));
		WebElement field_2 = driver.findElement(By.xpath("//input[@id='field2']"));
		
		WebElement copy_btn = driver.findElement(By.xpath("//button[normalize-space()='Copy Text']"));

		// clear the field
		field_1.clear();
		
		// Time delay
		Thread.sleep(3000);
		
		// sent string 
		field_1.sendKeys("Double click");
		
		// Time delay
		Thread.sleep(3000);
		
		// Create object of Actions class
		Actions action = new Actions(driver);
		
		// Perform the double click actions 
		action.doubleClick(copy_btn).perform();
		
		String text = field_2.getAttribute("value");
		System.out.println("Capture value : "+text);
		
		// verify that the text successefully copied
		if(field_2.getText().equalsIgnoreCase("Double click"))
		{
			System.out.println("Text Copied ...");
		}
		else
		{
			System.out.println("Text not copied properly ...");
		}
		
		
		// Time delay
		Thread.sleep(5000);
		
		// close session
		driver.quit();

	}

}
  
 
*/


/*

<!DOCTYPE html>
<html>
<body>

Field1: <input type="text" id="field1" value="Hello World!"><br>
Field2: <input type="text" id="field2"><br><br>

<button ondblclick="myFunction()">Copy Text</button>

<p>A function is triggered when the button is double-clicked. The function copies the text from Field1 into Field2.</p>

<script>
function myFunction() {
  document.getElementById("field2").value = document.getElementById("field1").value;
}
</script>

</body>
</html>


// Output of the html code
 
 Field1: 
Hello World!

Field2: 


Copy Text
A function is triggered when the button is double-clicked. The function copies the text from Field1 into Field2.



*/