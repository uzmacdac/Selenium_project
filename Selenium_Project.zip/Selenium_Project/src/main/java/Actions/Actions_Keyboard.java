package Actions;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Actions_Keyboard {

	// https://demo.nopcommerce.com/
	
	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																	
		// Maximize Browser window
		driver.manage().window().maximize();
													
		// https://demo.nopcommerce.com/
		driver.get("https://demo.nopcommerce.com/");
			
		// Create the object of the Actions class
		Actions action = new Actions(driver);
		
		// Explicit Wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		
		// Locating the Register element using xpath : //a[@class='ico-register' and contains(text(), 'Register')]
		WebElement register_link = driver.findElement(By.xpath("//a[@class='ico-register' and contains(text(), 'Register')]"));
				
		
		// Time delay 
		Thread.sleep(3000);
		
		// Try to click on register link using the keyboard 
		action.keyDown(Keys.CONTROL).click(register_link).keyUp(Keys.CONTROL).perform();
		
		// Time delay 
		Thread.sleep(5000);
		
		// Here the focus on the old window we have to switch focus to new window(register link window)
		// Switch to registration window
		// get the total window 
		// Here we get parent and child window ids
		//Set<String> windows_ids = driver.getWindowHandles();
		// Convert the Set<String>  into the list 
		List<String> ids_list = new ArrayList(driver.getWindowHandles());
				
		// now switch to window  ids_list.get(1) -> gives the id of the child window here registration page id
		// switch to registration page
		driver.switchTo().window(ids_list.get(1));
		
		
		
		// First Name input field - locate element using xpath  : //input[@id='FirstName']
		//WebElement first_name = driver.findElement(By.xpath("//input[@id='FirstName']"));
		WebElement first_name = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='FirstName']")));
		first_name.sendKeys("Bella");
		
		// now switch to window  ids_list.get(0) -> gives the id of the parent window here nopCommerce page id
		// switch to parent page
		driver.switchTo().window(ids_list.get(0));
		
		// Locate the search element on page using the xpath : //input[@id='small-searchterms']
		WebElement search =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='small-searchterms']")));
		search.sendKeys("TShirts");
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();
		
	}

}
