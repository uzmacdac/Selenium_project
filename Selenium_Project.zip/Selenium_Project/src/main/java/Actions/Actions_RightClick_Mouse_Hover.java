package Actions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actions_RightClick_Mouse_Hover {
	
	// https://demo.opencart.com/
	// https://swisnl.github.io/jQuery-contextMenu/demo.html

	public static void main(String[] args) throws InterruptedException {
				
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
							
		// https://swisnl.github.io/jQuery-contextMenu/demo.html	
		driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
		
		// Locate element using xpath : //span[@class='context-menu-one btn btn-neutral']
		WebElement right_click_btn = driver.findElement(By.xpath("//span[@class='context-menu-one btn btn-neutral']"));
		
		// Create Actions class object
		Actions action = new Actions(driver);
		
		// Right click on right click me button
		action.contextClick(right_click_btn)
		.perform();
		
		Thread.sleep(5000);
		
		// after clicking on it we get contextMenue 
		// click on copy menue
		WebElement copy_ele = driver.findElement(
				By.xpath("//li[@class='context-menu-item context-menu-icon context-menu-icon-copy']//span[contains(text(), 'Copy')]"));
		copy_ele.click();
		
		
		// Switch to the alert
        Alert alert = driver.switchTo().alert();
        
        // Get the alert text
        String alertText = alert.getText();
        System.out.println("Alert text: " + alertText);

        Thread.sleep(3000);
        
        // Accept the alert (click 'OK')
        alert.accept();
        
		Thread.sleep(5000);
		driver.quit();

	}

}


/*

public class Actions_RightClick_Mouse_Hover {
	
	// https://demo.opencart.com/
	// https://swisnl.github.io/jQuery-contextMenu/

	public static void main(String[] args) throws InterruptedException {
		
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
											
		// Maximize Browser window
		driver.manage().window().maximize();
							
		// https://demo.opencart.com/		
		driver.get("https://demo.opencart.com/");
		
		WebElement desktops = driver.findElement(By.linkText("Desktops"));
		
		Thread.sleep(2000);
		
		
		
		// Create object of the Actions class
		Actions action = new Actions(driver);
		
		// .moveToElement(mac)
		
		action.moveToElement(desktops)
		.build()
		.perform();
		
		WebElement mac = driver.findElement(By.linkText("Mac (1)"));
		
		action.moveToElement(mac)
		.click()
		.build()
		.perform();
		
		Thread.sleep(8000);
		driver.quit();

	}

}


*/