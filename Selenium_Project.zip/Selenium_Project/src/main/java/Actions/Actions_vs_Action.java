package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Actions_vs_Action {

	// https://testautomationpractice.blogspot.com/ 
	// https://demo.guru99.com/test/drag_drop.html
	
	public static void main(String[] args) {

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
													
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// https://swisnl.github.io/jQuery-contextMenu/demo.html	
		driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
				
		// Locate element using xpath : //span[@class='context-menu-one btn btn-neutral']
		WebElement right_click_btn = driver.findElement(By.xpath("//span[@class='context-menu-one btn btn-neutral']"));
			
		// Actions is class - will used to perform mouse actions
		// Create Actions class object
		Actions actions = new Actions(driver);
		
		// Action is an interface - will be used to store created actions
		// here we are creating the action
		Action my_action = actions.contextClick(right_click_btn).build();
		
		// we are performing or completing the actions
		my_action.perform();

	}

}
