package Dropdown;

import java.awt.Robot;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown_Select_SDETQA {
	
	// Hidden Dropdown - click on the dropdown show the list of option but it is not available in html source code
	
	// https://www.jquery-az.com/boots/demo.php?ex=63.0_2

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
											
		// Maximize Browser window
		driver.manage().window().maximize();
													
		// Open url : https://www.jquery-az.com/boots/demo.php?ex=63.0_2
		driver.get("https://www.jquery-az.com/boots/demo.php?ex=63.0_2");
		
		// dropdown is define using <select> tag
		
		// Time delay
		Thread.sleep(3000);
		
		

	}

}


/*

public class Dropdown_Select_SDETQA {
	
	// Bootstrap Dropdown
	
	// https://www.jquery-az.com/boots/demo.php?ex=63.0_2

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
											
		// Maximize Browser window
		driver.manage().window().maximize();
													
		// Open url : https://www.jquery-az.com/boots/demo.php?ex=63.0_2
		driver.get("https://www.jquery-az.com/boots/demo.php?ex=63.0_2");
		
		// dropdown is define using <select> tag
		
		// Time delay
		Thread.sleep(3000);
		
		// Open dropdown options
		// Locating the country dropdown using xpath  : //button[@class='multiselect-selected-text']
		// xpath : //button[contains(@class, 'multiselect')]
		WebElement  output_btn = driver.findElement(By.xpath("//button[contains(@class, 'multiselect')]"));
		output_btn.click();
		
		// 1) select single options
		driver.findElement(By.xpath("//input[@value='Java']")).click();
		
		// 2) Capture all the options
		List<WebElement> options_list = driver.findElements(By.xpath("//ul[contains(@class, 'multiselect')]//label"));
		System.out.println("Total number of Options : "+options_list.size());
		
		// 3) Print all the options 
		for(WebElement option : options_list) {
			System.out.println(option.getText());
		}
		
		// 4) Select Multiple Options
		for(WebElement option : options_list) {
			String opt = option.getText();
			if(opt.equalsIgnoreCase("Bootstrap") ||opt.equalsIgnoreCase("Python") || opt.equalsIgnoreCase("MySQL")) {
				option.click();
			}
		}

	}

}

*/


/*

public class Dropdown_Select_SDETQA {
	
	// Select dropdown
	
	// https://www.jquery-az.com/boots/demo.php?ex=63.0_2

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
											
		// Maximize Browser window
		driver.manage().window().maximize();
													
		// Open url : https://testautomationpractice.blogspot.com/
		driver.get("https://testautomationpractice.blogspot.com/");
		
		// dropdown is define using <select> tag
		
		// Time delay
		Thread.sleep(3000);
		
		// Locating the country dropdown using id  : country
		WebElement country_dropdown = driver.findElement(By.id("country"));
		
		// create instance of Select class to access the dropdown element
		Select options = new Select(country_dropdown);
		
		// select option from the dropdown
		options.selectByVisibleText("India");

	}

}

*/