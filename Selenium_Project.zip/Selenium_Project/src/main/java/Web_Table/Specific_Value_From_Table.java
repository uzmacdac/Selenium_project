package Web_Table;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class Specific_Value_From_Table {

//  https://www.dunzo.com/hyderabad/greenkart-kondapur?subTag=grocery
	// https://rahulshettyacademy.com/seleniumPractise/#/offers

	// 1- Requirements : After Click on the sorting (down arrow) the value in the column should be sorted 
	// 				 	 verify that the column is sorted	
	// 2- Requirements : To find the price of specific value in the column 
	// 				ex : giving rice we have to find out it's price
	
	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/offers
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		// 1- Requirements : After Click on the sorting (down arrow) the value in the column should be sorted 
		// 				  verify that the column is sorted	
	
		// Click on the column
		// Click on Veg/fruit name 
		WebElement column_heading = driver.findElement(By.xpath("//tr/th[1]"));
		column_heading.click();
		
		// 1. Capture all WebElement into list
		
		// //table[@class='table table-bordered']//tbody//tr//td[1]
		//List<WebElement> element_names = driver.findElements(By.xpath("//table[@class='table table-bordered']//tbody//tr//td[1]"));
		
		//  //tr//td[1]
		List<WebElement> element_names = driver.findElements(By.xpath("//tr//td[1]"));
		
		element_names.stream()
        .forEach(element -> System.out.println(element.getText()));
		
		System.out.println("-------------------------------------------------------------");
		
		// 2- Requirements : To find the price of specific value in the column 
		// ex : giving rice we have to find out it's price
	
		// Logic : 
		// 1. Scan the name column with the given text using getText --> print the price of the vegetable
		// we have already collected column elements in list element_names
		// Now we are using stream for the same 
		List<String> price = element_names.stream().filter(s->s.getText().contains("Bean"))  
		.map(s-> getPriceOfVegetables(s))
		.collect(Collectors.toList());
		price.forEach(s-> System.out.println(s));
		
		List<String> price_1 = element_names.stream().filter(s->s.getText().equals("Beans"))  
				.map(s-> getPriceOfVegetables(s))
				.collect(Collectors.toList());
				
		price_1.forEach(s-> System.out.println(s));
		
		for(WebElement veg : element_names)
		{
			if(veg.getText().contains("Bean"))
			{
				String price_veg = getPriceOfVegetables(veg);
				System.out.println(price_veg);
			}
		}
		
		// Scan the column with the getText() 
		// -> Rice -> print the price of the 
		
		//System.out.println("Filter");

		//element_names.stream().filter(s->s.getText().contains("Beam")).forEach(s-> System.out.println(s.getText()));


		
		System.out.println("-------------------------------------------------------------");
		
		
		// Time delay
		Thread.sleep(5000);
							
		// close 
		driver.quit();
		
	}

	private static String getPriceOfVegetables(WebElement vegetable) {
		
		System.out.println("Inside func : "+vegetable.getText());
		// To get the price of the vegetable, here we can seen price is nothing but the following sibling of the Bean element
		//WebElement price_element = vegetable.findElement(By.xpath("following-sibling::td[1]"));
		WebElement price_element = vegetable.findElement(By.xpath("following-sibling::td[1]"));
		String price = price_element.getText();
		System.out.println(price);
		return price;
	}


}
