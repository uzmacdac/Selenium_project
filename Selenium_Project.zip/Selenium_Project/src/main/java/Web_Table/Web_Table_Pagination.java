package Web_Table;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Web_Table_Pagination {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/offers
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		// 1- Requirements : After Click on the sorting (down arrow) the value in the column should be sorted 
		// 				  verify that the column is sorted	
	
		// Click on the column
		// Click on Veg/fruit name 
		WebElement column_heading = driver.findElement(By.xpath("//tr/th[1]"));
		column_heading.click();
		
		// 1. Capture all WebElement into list
		
		// //table[@class='table table-bordered']//tbody//tr//td[1]
		//List<WebElement> element_names = driver.findElements(By.xpath("//table[@class='table table-bordered']//tbody//tr//td[1]"));
		
		//  //tr//td[1]
		List<WebElement> element_names = driver.findElements(By.xpath("//tr//td[1]"));
		
		element_names.stream()
        .forEach(element -> System.out.println(element.getText()));
		
		System.out.println("-------------------------------------------------------------");
		
		List<String> price;
		
		do
		{
			// 2- Requirements : To find the price of specific value in the column 
			// ex : giving rice we have to find out it's price
			List<WebElement> rows = driver.findElements(By.xpath("//tr//td[1]"));
		
			// Logic : 
			// 1. Scan the name column with the given text using getText --> print the price of the vegetable
			// we have already collected column elements in list element_names
			// Now we are using stream for the same 

			// Here we are searching for Rice but after sorting it is not available on the page
			// since it is not available on the page then s-> getPriceOfVegetable(s) will null and list don't have any value
			// so the size of the price_1 list will be zero 
			price = rows.stream().filter(s->s.getText().equals("Rice"))  
					.map(s-> getPriceOfVegetables(s))
					.collect(Collectors.toList());
					
			price.forEach(s-> System.out.println(s));
					
			// Scan the column with the getText() 
			// -> Rice -> print the price of the 			
			//System.out.println("Filter");
			//element_names.stream().filter(s->s.getText().contains("Beam")).forEach(s-> System.out.println(s.getText()));			
			if(price.size() < 1 )
			{
				// if size of the list is less than 0 that means list is empty and the table on the web page does not contain that item 
				// but wet table have page so we have to find the item in next page of the web table 
				// click on the next page
				WebElement next_page_in_table = driver.findElement(By.cssSelector("a[aria-label=\"Next\"]"));
				next_page_in_table.click();
			}		
			
		}
		while(price.size() < 1);
		
		
		
		
		
		
		System.out.println("-------------------------------------------------------------");
		
		
		// Time delay
		Thread.sleep(5000);
							
		// close 
		driver.quit();
		
	}

	private static String getPriceOfVegetables(WebElement vegetable) {
		
		System.out.println("Inside func : "+vegetable.getText());
		// To get the price of the vegetable, here we can seen price is nothing but the following sibling of the Bean element
		//WebElement price_element = vegetable.findElement(By.xpath("following-sibling::td[1]"));
		WebElement price_element = vegetable.findElement(By.xpath("following-sibling::td[1]"));
		String price = price_element.getText();
		System.out.println(price);
		return price;
	}

}
