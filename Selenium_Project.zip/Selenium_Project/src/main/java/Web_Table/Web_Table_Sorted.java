package Web_Table;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class Web_Table_Sorted {
	
	//  https://www.dunzo.com/hyderabad/greenkart-kondapur?subTag=grocery
	// https://rahulshettyacademy.com/seleniumPractise/#/offers

	// 1- Requirements : After Click on the sorting (down arrow) the value in the column should be sorted 
	// 				 	 verify that the column is sorted	
	// 2- Requirements : To find the price of specific value in the column 
	// 				ex : giving rice we have to find out it's price
	
	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/offers
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		// 1- Requirements : After Click on the sorting (down arrow) the value in the column should be sorted 
		// 				  verify that the column is sorted	
	
		// Click on the column
		// Click on Veg/fruit name 
		WebElement column_heading = driver.findElement(By.xpath("//tr/th[1]"));
		column_heading.click();
		
		// 1. Capture all WebElement into list
		
		// //table[@class='table table-bordered']//tbody//tr//td[1]
		//List<WebElement> element_names = driver.findElements(By.xpath("//table[@class='table table-bordered']//tbody//tr//td[1]"));
		
		//  //tr//td[1]
		List<WebElement> element_names = driver.findElements(By.xpath("//tr//td[1]"));
		
		// 2. Capture text of all WebElement into new list (orignal list)
		List<String> original_list = element_names.stream().map(s->s.getText()).collect(Collectors.toList());
		
		System.out.println("-------------------------------------------------------------");
										
		System.out.println("Original List : ");
		for(String name : original_list)
		{
			System.out.println(name);
		}
		
		System.out.println("-------------------------------------------------------------");
		System.out.println("Sorted Lsit : ");
		
		// 3. Sort the list -> get the sorted list 
		List<String> sorted_list = original_list.stream().sorted().collect(Collectors.toList());
		
		for(String name : sorted_list)
		{
			System.out.println(name);
		}
		
		// 4. Compare the both the list orignal list and sorted list 
		Assert.assertTrue(original_list.equals(sorted_list));
		
		System.out.println("-------------------------------------------------------------");
		if (original_list.equals(sorted_list)) {
            System.out.println("The lists are identical.");
        } else {
            System.out.println("The lists are not identical.");
        }
		
		System.out.println("-------------------------------------------------------------");
	
		
		// Time delay
		Thread.sleep(5000);
							
		// close 
		driver.quit();
		
	}

	

}
