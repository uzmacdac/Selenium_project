package JavascriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavascriptExecutor_demo {
	
	// https://www.countries-ofthe-world.com/all-countries.html

public static void main(String[] args) throws InterruptedException {
		
		// url open : https://demo.nopcommerce.com/

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Create the reference of the JavascripExecutor
		JavascriptExecutor js = (JavascriptExecutor) driver;
																
		// Maximize Browser window
		driver.manage().window().maximize();
		
		
																					
		// Open url : 	https://demo.nopcommerce.com/	
		driver.get("https://demo.nopcommerce.com/");
		
		// 1) Scroll down the page by pixel number
		js.executeScript("window.scrollBy(0, 3000);", "");
		// return the value
		System.out.println(js.executeScript("return window.pageYOffset;"));
		
		// Time delay 
		Thread.sleep(3000);
		
		// 2) Scroll down the page till the element is visible
		WebElement community_poll = driver.findElement(By.xpath("//div//strong[contains(text(), 'Community poll')]"));
		js.executeScript("arguments[0].scrollIntoView();", community_poll);
		System.out.println("Scroll till the Element visible Offset : "+ js.executeScript("return window.pageYOffset;"));
		
		// Time delay 
		Thread.sleep(3000);
		
		// 3) Scroll the page till the end of the page.
		js.executeScript("window.scrollBy(0, document.body.scrollHeight);", "");
		System.out.println("Scroll till the End of the page Offset : "+ js.executeScript("return window.pageYOffset;"));
		
		// Time delay 
		Thread.sleep(3000);
		
		// 4) Scroll up to the initial position
		js.executeScript("window.scrollBy(0, -document.body.scrollHeight);", "");
		System.out.println("Scroll initial position of the page Offset : "+ js.executeScript("return window.pageYOffset;"));
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();
		
	}

}


/*

	
	// https://www.countries-ofthe-world.com/all-countries.html

public static void main(String[] args) throws InterruptedException {
		
		// url open : https://testautomationpractice.blogspot.com/

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url : 	https://testautomationpractice.blogspot.com/			
		driver.get("https://testautomationpractice.blogspot.com/");
		
		// Locate input name : using id : name
		//WebElement name = driver.findElement(By.id("name"));
		//name.sendKeys("Sebastian");
		
		// the same action perform using JavascripExecutor
		// create reference of JavascriptExecutor because it is interface 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		WebElement name = driver.findElement(By.id("name"));
		js.executeScript("arguments[0].setAttribute('value', 'Sebastian');", name);
		
		// Time delay
		Thread.sleep(2000);
		
		// Locate radio button using id : male
		WebElement female_radio_btn = driver.findElement(By.id("female"));
		js.executeScript("arguments[0].click();", female_radio_btn);
		
		
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();
		
	}

}



*/