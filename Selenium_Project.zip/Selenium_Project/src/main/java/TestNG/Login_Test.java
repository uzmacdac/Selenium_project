package TestNG;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/*
 
  TestNG Configuration
  1. Install TestNG in Eclipse.
  2. Add Testing library to build path/ add testing dependency in pom.xml
  
  Note :
  1. TestNG execute the test methods based on the Alphabetical order.
    Common Attributes of the @Test Annotation:
    priority: Used to define the priority of the test method. Tests with a lower priority 
    value are run before tests with higher priority values. The default priority is 0.

    java
    @Test(priority = 1)
    public void testMethod1() { ... }
 2. @Test(priority=num) -> controls the order of execution.
 3. The default priority is 0.
 4. Once you provide priority to the test methods, then the order of the methods is not 
    considered.
 5. Priorities can be random numbers(No need to have consecutive number).
 6. If multiple test case have same priority then those test case execute in 
    Alphabetical order.
 7. We can provide negative number as priority
    @Test(priority=-num)
    Negative values (or number) are allowed in priority.
    -4 -3 -2 -1 0 1 2 3 4
 8. TestNG execute test methods only if they are having @Test annotation 


 */

public class Login_Test {


	//private static final String[][] Object = null;


	@Test(dataProvider = "getData")
	public void loginTest(String username, String password)
	{
		
		System.out.println("Inside the Login_Test loginTest test");
		System.out.println("Username : "+ username);
		System.out.println( "Password : "+ password);
	}
	
	@Parameters({"URL"})
	@Test
	public void webLoginCarLoan(String url)
	{
		
		System.out.println("Inside the Login_Test webLoginCarLoan test");
		System.out.println("URL : "+url);
	}
	
	@Test
	public void mobileLoginTest()
	{
		
		System.out.println("Inside the Login_Test mobileLoginTest test");
	}
	
	@Test(groups= {"Smoke"})
	public void mobilSignupTest()
	{
		
		System.out.println("Inside the Login_Test mobilSignupTest test");
	}
	
	//@BeforeSuite
	public void initialSetupforTest() 
	{
		System.out.println("Before Suite execution");
		
		
	}
	
	
	//@BeforeMethod
	public void beforeMethodExecute()
	{
		System.out.println("Execute before every test method");
	}
	
	
	@Test(dependsOnMethods="mobileLoginTest")
	public void mobileMediaTest()
	{
		
		System.out.println("Inside the Login_Test mobileMediaTest test");
	}
	
	
	@DataProvider
	public Object[][] getData() {
		// 1. Combination - username password - good credit  history 
		// 2. username password - no credit history
		// 3. Fradulent credit history
		Object[][] data = new Object[3][2];
		data[0][0] = "FirstSetUsername";
		data[0][1] = "passwprd1";
		
		data[1][0] = "sdcondSetUSername";
		data[1][1] = "passwprd2";
 				
		data[2][0] = "thirdSetUsername";
		data[2][1] = "password3";
		
		return data;
 	}
	
}
