package TestNG;

import org.testng.annotations.Test;

public class Loan_Test {
	
	@Test
	public void pLoan()
	{
		
		System.out.println("Inside the ploan test");
	}
	

	@Test
	public void p()
	{
		
		System.out.println("Inside the p test");
	}

}
