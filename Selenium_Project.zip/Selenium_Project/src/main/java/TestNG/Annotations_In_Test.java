package TestNG;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations_In_Test {

	
	@BeforeTest
	public void employee_salary()
	{
		System.out.println("Employee salary");
	}
	
	
	@Test(groups= {"Smoke"})
	public void employee_name()
	{
		System.out.println("Employee name");
	}
	
	
	
	@Test(groups= {"Smoke"})
	public void employe_detail()
	{
		System.out.println("Employee detail");
	}
	
	@AfterTest
	public void employe_annual_package()
	{
		System.out.println("Employee Annaul Package");
	}
	
}
