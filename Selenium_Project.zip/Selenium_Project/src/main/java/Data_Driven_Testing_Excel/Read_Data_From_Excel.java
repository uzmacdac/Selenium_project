package Data_Driven_Testing_Excel;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Read_Data_From_Excel {

	public static void main(String[] args) throws IOException {
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		//WebDriver driver = new ChromeDriver();
		
		// Open file in reading Mode
		FileInputStream file = new FileInputStream("D:\\Selenium_Java\\Selenium_WebDriver\\Selenium_Project\\src\\main\\java\\Data_Driven_Testing_Excel\\Demo.xlsx");
		
		// Create instance of the workbook
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		
		// Extract the sheets from the workbook
		// if you are using workbook.getSheet("Name_of_Sheet") we have to pass the name of the Sheets
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		
		//System.out.println("sheet : "+sheet);
		
		
		// if you are extracting Sheet by its index then use 
		// If you are using workbook.getSheetAt(index) then we have to pass index of the sheet
		//XSSFSheet sheet = workbook.getSheetAt(1);
		System.out.println("sheet : "+sheet);
		
		// Get the total row in the table in excel
		int total_rows = sheet.getLastRowNum();
		System.out.println("Total Row : "+total_rows);
		
		// Get the total column in the table in the excel
		short total_cells = sheet.getRow(0).getLastCellNum();
		
		System.out.println("Total Cell : "+total_cells);
		
		// Traverse through the all row
		for(int r = 0 ; r <= total_rows ; r++ )
		{
			XSSFRow current_row = sheet.getRow(r);
			
			// traverse through all cell or the current row
			for(int c=0 ; c < total_cells ; c++)
			{
				XSSFCell current_cell = current_row.getCell(c);
				System.out.println(current_cell.toString()+"\t");
			}
			System.out.println();
		}
		
		
		// close workbook
		try {
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// close file
		try {
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}