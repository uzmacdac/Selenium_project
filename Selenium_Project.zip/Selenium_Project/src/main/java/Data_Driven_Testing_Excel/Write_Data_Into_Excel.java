package Data_Driven_Testing_Excel;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.IndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




public class Write_Data_Into_Excel {

	public static void main(String[] args) throws IOException {
		
		// To write the data into the file we are using FileOutputStream
		// Open file in writing mode
		FileOutputStream  file = new FileOutputStream("D:\\Selenium_Java\\Selenium_WebDriver\\Selenium_Project\\src\\main\\java\\Data_Driven_Testing_Excel\\Book.xlsx");
		
		// Create instance of the workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		// Create Sheet to write data 
		XSSFSheet sheet = workbook.createSheet("Data");
		
		// Create row in the sheet of excel
		XSSFRow row1 = sheet.createRow(0);
		
		// Create header cells with the bold style 
		XSSFCellStyle header_style = workbook.createCellStyle();
		
		// Font in the header
		XSSFFont font =  workbook.createFont();
		
		// bolder the header 
		font.setBold(true);
		
		// set the font style 
		header_style.setFont(font);
		
		// Light yellow header background
		//header_style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());  
		
		
		
		 // Create a custom color using RGB (Yellow: R=255, G=255, B=0)
		header_style.setFillBackgroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
		
		header_style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		
		 // Create  cell 
        row1.createCell(0).setCellValue("Type");
        row1.createCell(1).setCellValue("Book Name");
        row1.createCell(2).setCellValue("Author");
        row1.createCell(3).setCellValue("Price");

        // Create the row in the sheet
        XSSFRow row2 = sheet.createRow(1);

        // Create  cell 
        row2.createCell(0).setCellValue("Fictional");
        row2.createCell(1).setCellValue("Harry Potter and the Chamber of Secrets");
        row2.createCell(2).setCellValue("J.K. Rowling");
        row2.createCell(3).setCellValue("1000");
        
        // Create the row in the sheet
        XSSFRow row3 = sheet.createRow(2);

        // Create  cell 
        row3.createCell(0).setCellValue("Fictional");
        row3.createCell(1).setCellValue("Twilight");
        row3.createCell(2).setCellValue("Stephenie Meyer");
        row3.createCell(3).setCellValue("600");


        // Create the row in the sheet
        XSSFRow row4 = sheet.createRow(3);

        // Create  cell 
        row4.createCell(0).setCellValue("Fictional");
        row4.createCell(1).setCellValue("The Great Gatsby");
        row4.createCell(2).setCellValue("F. Scott Fitzgerald");
        row4.createCell(3).setCellValue("200");
        
        // Create the row in the sheet
        XSSFRow row5 = sheet.createRow(4);

        // Create  cell 
        row5.createCell(0).setCellValue("Adventure");
        row5.createCell(1).setCellValue("Moby Dick");
        row5.createCell(2).setCellValue("Herman Melville");
        row5.createCell(3).setCellValue("250");

        // Create the row in the sheet
        XSSFRow row6 = sheet.createRow(5);

        // Create  cell 
        row6.createCell(0).setCellValue("Thriller");
        row6.createCell(1).setCellValue("The Girl with the Dragon Tattoo");
        row6.createCell(2).setCellValue("Stieg Larsson");
        row6.createCell(3).setCellValue("500");

        
        // write workbook to file
        workbook.write(file);

        


        // Close Workbook
        workbook.close();

        // close file
        file.close();


		
		
		
		
	}

}
