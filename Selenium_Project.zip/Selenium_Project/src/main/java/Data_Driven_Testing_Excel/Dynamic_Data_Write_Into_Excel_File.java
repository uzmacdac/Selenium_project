package Data_Driven_Testing_Excel;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Dynamic_Data_Write_Into_Excel_File {

	public static void main(String[] args) throws IOException, InterruptedException {


		 // open the file in writing mode
        FileOutputStream file = new FileOutputStream("D:\\\\Selenium_Java\\\\Selenium_WebDriver\\\\Selenium_Project\\\\src\\\\main\\\\java\\\\Data_Driven_Testing_Excel\\Dynamic_Data.xlsx");
        
        // create instance of workbook
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create sheet to write a data
        XSSFSheet sheet = workbook.createSheet("Dyanmic_Data");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter numnber of rows : ");
        int total_rows = sc.nextInt();

        System.out.println("Enter number of cells : ");
        int total_cells = sc.nextInt();
        
        // creating  row
        for(int r=0 ; r<= total_rows ; r++)
        {
            XSSFRow row = sheet.createRow(r);

            // creating the cell 
            for(int c=0 ; c<total_cells ; c++)
            {
                XSSFCell cell = row.createCell(c);
                System.out.println("Enter the Cell Value : ");
                cell.setCellValue(sc.next());
            }
        }

        
        // write workbook to file
        workbook.write(file);

        


        // Close Workbook
        workbook.close();

        // close file
        file.close();


        //Delay execution for 5 seconds to view the maximize operation
        Thread.sleep(5000);


		
		
	}

}
