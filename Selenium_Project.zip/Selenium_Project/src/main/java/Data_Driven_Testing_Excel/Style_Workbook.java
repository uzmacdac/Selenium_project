package Data_Driven_Testing_Excel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Style_Workbook {

    public static void main(String[] args) throws IOException {
        // Create a new workbook and sheet
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("To-Do List");

        // Create a header row
        Row headerRow = sheet.createRow(0);

        // Create header cells with bold font
        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);

        // Add headers to columns
        Cell taskHeader = headerRow.createCell(0);
        taskHeader.setCellValue("Task");
        taskHeader.setCellStyle(headerStyle);

        Cell statusHeader = headerRow.createCell(1);
        statusHeader.setCellValue("Status");
        statusHeader.setCellStyle(headerStyle);

        // Add some tasks to the to-do list
        Object[][] taskData = {
                {"Buy groceries", "Pending"},
                {"Clean the house", "Completed"},
                {"Finish project report", "In Progress"},
                {"Call the plumber", "Pending"}
        };

        // Populate the sheet with task data
        int rowNum = 1;
        for (Object[] task : taskData) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue((String) task[0]);
            row.createCell(1).setCellValue((String) task[1]);
        }

        // Auto-size columns for better visibility
        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("D:\\\\Selenium_Java\\\\Selenium_WebDriver\\\\Selenium_Project\\\\src\\\\main\\\\java\\\\Data_Driven_Testing_Excel\\To_do_list.xlsx");
        workbook.write(fileOut);
        fileOut.close();

        // Close the workbook
        workbook.close();

        System.out.println("Excel file created successfully.");
    }
}
