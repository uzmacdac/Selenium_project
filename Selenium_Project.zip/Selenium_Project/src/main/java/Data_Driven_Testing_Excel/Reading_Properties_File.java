package Data_Driven_Testing_Excel;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Properties;
import java.util.Set;

public class Reading_Properties_File {

	public static void main(String[] args) throws IOException {
		
		// 1. Open file in reading mode
		FileInputStream file = new FileInputStream("D:\\Selenium_Java\\Selenium_WebDriver\\Selenium_Project\\test_data\\config.properties");
		
		// 2. Create properties instance 
		Properties properties_obj = new Properties();
		
		// Loading Properties file 
		properties_obj.load(file);
		
		// Reading data from the  Properties file
		String url = properties_obj.getProperty("app_url");
		String email = properties_obj.getProperty("email");
		String password = properties_obj.getProperty("password");
		String order_id = properties_obj.getProperty("orderid");
		String customer_id = properties_obj.getProperty("customerid");
		
		System.out.println("---------------------------------------------------------------------------------------------------------");
		
		System.out.println("App url : "+url+"\nEmail : "+email+"\nPassword : "+password+"\nOrder id : "+order_id+"\nCustomer id : "+customer_id);
		
		System.out.println("---------------------------------------------------------------------------------------------------------");
		
		// Reading all keys from the properties file
        // first approach
        Set<String> keys = properties_obj.stringPropertyNames();
        System.out.println(keys);

        // second approach
        Set<Object> key = properties_obj.keySet();
        System.out.println(keys);

        // Reading all the values from properties file
        Collection<Object> values = properties_obj.values();
        System.out.println(values);

        System.out.println("---------------------------------------------------------------------------------------------------------");
	}

}
