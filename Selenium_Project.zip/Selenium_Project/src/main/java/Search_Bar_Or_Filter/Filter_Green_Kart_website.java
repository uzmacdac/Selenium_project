package Search_Bar_Or_Filter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class Filter_Green_Kart_website {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/offers
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
		System.out.println("-------------------------------------------------------------");
		
		// Locate search bar element using xpath :  input#search-field
		// search "Rice" 
		WebElement search_bar = driver.findElement(By.cssSelector("input#search-field"));
		search_bar.sendKeys("Rice");
		
		List<WebElement> vegetables_list = driver.findElements(By.xpath("//tr/td[1]"));
		vegetables_list.stream()
		.forEach(element -> System.out.println(element.getText()));
		
		
		// all vegetables are stored in list of webElement 
		List<WebElement> filtered_vegetables_list = vegetables_list.stream()
		.filter(veggies-> veggies.getText().contains("Rice") )
		.collect(Collectors.toList());
		
		filtered_vegetables_list.stream()
		.forEach(element -> System.out.println(element.getText()));
		
		// verify that the list are equal 
		Assert.assertEquals(vegetables_list.size(), filtered_vegetables_list.size());
		
		// Time delay
		Thread.sleep(5000);
							
		// close 
		driver.quit();
		

	}

}
