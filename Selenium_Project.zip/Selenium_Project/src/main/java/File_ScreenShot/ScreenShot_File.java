package File_ScreenShot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScreenShot_File {
	
	// How to capture Screenshot
	// 1) Full Page.
	// Selenium 4 on ward we can save screen shot for specific and web element 
	// 2) Specific area of the Page.
	// 3) Web Element.

	public static void main(String[] args) throws InterruptedException, IOException {

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://www.google.com/
		driver.get("https://www.google.com/");	
		
		// create file reference
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(src, new File("D:\\Selenium_Java\\ScreenShots\\screenshot_selenium.png"));
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
	}

}
