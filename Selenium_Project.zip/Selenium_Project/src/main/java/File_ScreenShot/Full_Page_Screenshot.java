package File_ScreenShot;

import java.io.File;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Full_Page_Screenshot {

	// interface information :  https://www.lambdatest.com/blog/selenium-4-webdriver-hierarchy/#:~:text=WebDriver%20interface%20has%20the%20following%20nested%20interfaces%3A,Timeouts
	
	
	public static void main(String[] args) throws InterruptedException {

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
				
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
				
		// If you are trying to take screen shot you better maximize the screen(window of browser) else it will capture small browser window screen shot
		// Maximize Browser window
		driver.manage().window().maximize();
																								
		// Open url :  https://www.opencart.com/index.php?route=cms/demo
		driver.get("https://www.opencart.com/index.php?route=cms/demo");		
		
		
		// 1) Full Page 
		
		// create reference or object of TakesScreenshot
		TakesScreenshot t_screen_shot = (TakesScreenshot)driver;
		
		// Create File reference 
		File source_file = t_screen_shot.getScreenshotAs(OutputType.FILE);
		
		// Create file reference for target
		File target_file = new File("D:\\Selenium_Java\\ScreenShots\\full_page.png");
		
		// copy source file to target file 
		source_file.renameTo(target_file);
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();

	}

}
