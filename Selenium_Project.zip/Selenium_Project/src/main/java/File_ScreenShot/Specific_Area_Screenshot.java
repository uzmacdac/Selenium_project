package File_ScreenShot;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Specific_Area_Screenshot {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
				
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
				
		// If you are trying to take screen shot you better maximize the screen(window of browser) else it will capture small browser window screen shot
		// Maximize Browser window
		driver.manage().window().maximize();
																								
		// Open url :  https://demo.nopcommerce.com/
		driver.get("https://demo.nopcommerce.com/");		
		
		
		// 2) Capture the screen shot for Specific area of the Page.
		
		// Locate element of Feature using xpath : //div[@class='product-grid home-page-product-grid']
		WebElement feature_product_section = driver.findElement(By.xpath("//div[@class='product-grid home-page-product-grid']"));		
		
		// Time delay
		//Thread.sleep(3000);
		
		// Create file reference for source 
		File source_file = feature_product_section.getScreenshotAs(OutputType.FILE);
		
		// Create file reference for target
		File target_file = new File("D:\\Selenium_Java\\ScreenShots\\specific_area.png");
		
		// copy source file to target file 
		source_file.renameTo(target_file);
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();

	}

}
