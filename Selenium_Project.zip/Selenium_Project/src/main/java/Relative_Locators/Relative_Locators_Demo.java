package Relative_Locators;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

public class Relative_Locators_Demo {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome driver		
		WebDriver driver = new ChromeDriver();		
		
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://rahulshettyacademy.com/angularpractice/
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		
		// Locate the name edit box  -> //input[@name='name' and @class='form-control ng-pristine ng-invalid ng-touched']
		WebElement name_editbox = driver.findElement(By.xpath("//input[@name='name']"));
		
		// get the label text by locating element using relative locator
		String name_txt = driver.findElement(RelativeLocator.with(By.tagName("label")).above(name_editbox)).getText();
		System.out.println("Name Text using Relative Locators : "+name_txt);
		
		// Locate Email input
		WebElement email_label = driver.findElement(By.xpath("//label[text()='Email']"));
		
		WebElement email = driver.findElement(RelativeLocator.with(By.xpath("//input[@name='email']")).below(email_label));
		email.sendKeys("abcd@gmail.com");
		
		Thread.sleep(2000);
		
		// Locate password label
		WebElement password_label = driver.findElement(By.cssSelector("label[for='exampleInputPassword1']"));
		WebElement password = driver.findElement(RelativeLocator.with(By.id("exampleInputPassword1")).below(password_label));
		password.sendKeys("abc@124");
		
		// locating date label 
		WebElement date_label = driver.findElement(By.tagName("label"));
		
		// Locat date input box using relative locator 
		WebElement date = driver.findElement(RelativeLocator.with(By.tagName("input")).below(date_label));
		date.sendKeys("15/02/2025");
		
		
		// Time delay
		Thread.sleep(5000);
							
		// close 
		driver.quit();
		
		

	}

}
