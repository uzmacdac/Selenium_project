package Shadow_DOM;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Shadow_Dom_Demo {

	// https://dev.automationtesting.in/shadow-dom
	
	
	public static void main(String[] args) throws InterruptedException {
		

		// Create object of the ChromeOptions
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  https://dev.automationtesting.in/shadow-dom
		driver.get("https://dev.automationtesting.in/shadow-dom");	
		
		//This Element is inside 3 nested shadow DOM.
		String cssSelectorForHost1 = "#shadow-root";
		String cssSelectorForHost2 = "#inner-shadow-dom";
		String cssSelectorForHost3 = "#nested-shadow-dom";
		Thread.sleep(1000);
		SearchContext shadow0 = driver.findElement(By.cssSelector("#shadow-root")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#inner-shadow-dom")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow2 = shadow1.findElement(By.cssSelector("#nested-shadow-dom")).getShadowRoot();
		Thread.sleep(1000);
		
		String text = shadow2.findElement(By.cssSelector("#multi-nested-shadow-element")).getText();
		System.out.println("Text : "+text);
		
		
		
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
		
	}

}
