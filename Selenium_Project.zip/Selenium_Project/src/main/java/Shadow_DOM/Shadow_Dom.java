package Shadow_DOM;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Shadow_Dom {
	
	// Important Notes: We can not locate the element present inside the Shadow DOM by using xpath. Only using css Selector we can locate the element.
	
	
	// https://dev.automationtesting.in/shadow-dom
	
	// https://books-pwakit.appspot.com/

	public static void main(String[] args) throws InterruptedException {

		// Create object of the ChromeOptions
		ChromeOptions options = new ChromeOptions();
		
		List<String> switches = Arrays.asList("enable-automation");
		options.setExperimentalOption("excludeSwitches", switches);
		
		
		// Launch Chrome Browser
	    // Initialize ChromeDriver with the ChromeOptions
		WebDriver driver = new ChromeDriver(options);
		
		// Maximize Browser window
		driver.manage().window().maximize();
																						
		// Open url :  
		driver.get("https://books-pwakit.appspot.com/");	
		
		// Locate element using css Selector :  book-app[apptitle='BOOKS']
		// This Element is inside single shadow DOM.
		String cssSelectorForHost1 = "book-app[apptitle='BOOKS']";
		Thread.sleep(1000);
		SearchContext shadow = driver.findElement(By.cssSelector("book-app[apptitle='BOOKS']")).getShadowRoot();
		Thread.sleep(1000);
		shadow.findElement(By.cssSelector("book-favorites[class='_page']"));
		
		
		
		
		
		
		
		
		// Time delay
		Thread.sleep(5000);
					
		// close 
		driver.quit();
				
	}

}
