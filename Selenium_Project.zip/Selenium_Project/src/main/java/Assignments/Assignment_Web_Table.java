package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.*;

public class Assignment_Web_Table {

	public static void main(String[] args) throws InterruptedException {
	
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																					
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
		
		// Scroll to Web Table Fix Header
		// Scroll the window or browser to 500
		js.executeScript("window.scrollBy(0, 500)");
		
		// Time delay
		Thread.sleep(2000);	
		
		// Locate the Web Table Example - instrcutor and course table
		// using xpath : //table[@id='prodList<A> and @name='courses']//tbody//tr
		List<WebElement> instructor_table_row = driver.findElements(By.xpath("//table[@id='product' and @name='courses']//tbody//tr"));
		System.out.println("Total row of the table : "+instructor_table_row.size());
		
		// Total coloumn using xpath : //table[@id='product' and @name='courses']//tbody//tr//th 
		// Total Coloumn using css selector  :  div[class='left-align'] th
		List<WebElement> instrcutor_table_coloumn = driver.findElements(By.cssSelector("div[class='left-align'] th"));
		System.out.println("Total coloumn of the table : "+instrcutor_table_coloumn.size());
		
		List<WebElement> second_row = driver.findElements(By.cssSelector("div[class='left-align'] tr:nth-child(3)"));
//		for(WebElement sec_row_content : second_row)
//		{
//			System.out.println(sec_row_content.getText()+" | ");
//		}
		
		
		
		for(int i=0 ; i < second_row.size() ; i++ )
		{
			System.out.println(second_row.get(i).getText());
			
		}
		
//		
		
		// Time delay
		Thread.sleep(5000);
								
		// close windows
		driver.quit();

	}

}
