package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_Frames {

	public static void main(String[] args) throws InterruptedException {
		
		// url open : https://the-internet.herokuapp.com/nested_frames

		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
															
		// Maximize Browser window
		driver.manage().window().maximize();
																			
		// Open url : https://the-internet.herokuapp.com/nested_frames
		//driver.get("https://the-internet.herokuapp.com/nested_frames");
		
		driver.get("https://the-internet.herokuapp.com/");
			
		// Time Delay
		Thread.sleep(3000);
		
		// Locate the Nested Frame  element
		WebElement nested_frame = driver.findElement(By.linkText("Nested Frames"));
		nested_frame.click();
		
		// Time Delay
		Thread.sleep(3000);
		
		System.out.println("Nested Frame ");
		
		// Switch to the top frame
        driver.switchTo().frame("frame-top");
        
        // Switch to the top frame
        //driver.switchTo().frame("frame-middle");
        
        WebElement middle_frame_element = driver.findElement(By.xpath("//frame[@name='frame-middle']"));
        
        driver.switchTo().frame(middle_frame_element);
        
        WebElement content = driver.findElement(By.xpath("//div[@id='content']"));
        System.out.println("Content of Middle frame : "+content.getText());
        
		
	}

}
