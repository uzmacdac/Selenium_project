package Assignments;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_Window_Handling {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
									
		// Maximize Browser window
		driver.manage().window().maximize();
													
		// Open url : https://the-internet.herokuapp.com/windows
		driver.get("https://the-internet.herokuapp.com/windows");
		
		// using implicit wait 
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Time delay
		Thread.sleep(3000);
		
		// click on Click Here button using xpath : //a[contains(@href,'/windows/new') and contains(text(), 'Click Here') ]
		WebElement click_here_btn = driver.findElement(
				By.xpath("//a[contains(@href,'/windows/new') and contains(text(), 'Click Here') ]")
				);
		click_here_btn.click();
		
		// get windows id 
		Set<String> windowHandles = driver.getWindowHandles();
		
		// iterate over set 
		Iterator<String> itr = windowHandles.iterator();
		
		// iterate over parentId ChildId 
		// Storing parentid : By doing  itr.next() control goes to first element 
		String parenId = itr.next();
				
		// Storing childid : we have to traver again itr.next()
		String childId = itr.next();
				
		// Switching driver to child window
		driver.switchTo().window(childId);
		
		WebElement child_window_content = driver.findElement(By.cssSelector("div h3"));
		System.out.println("Child Window content : "+child_window_content.getText());

		// Time delay
		Thread.sleep(3000);
		
		// Switching driver to parent window
		driver.switchTo().window(parenId);
		
		WebElement parent_window_content = driver.findElement(By.cssSelector("div h3"));
		System.out.println("Parent Window content : "+parent_window_content.getText());
	}

}
