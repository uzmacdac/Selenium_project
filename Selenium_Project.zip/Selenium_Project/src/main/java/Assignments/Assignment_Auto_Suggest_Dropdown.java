package Assignments;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment_Auto_Suggest_Dropdown {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																					
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
		
		// click on auto suggest dropdown 
		WebElement auto_dropdow = driver.findElement(By.cssSelector("input#autocomplete"));
		auto_dropdow.click();
		
		auto_dropdow.sendKeys("ind");
		
		// Create the object of the Actions class
		Actions action = new Actions(driver);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		// Wait untill the element is visible on page
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']//li[@class='ui-menu-item']")));
		
		List<WebElement> options = driver.findElements(By.xpath("//ul[@id='ui-id-1']//li[@class='ui-menu-item']"));

		System.out.println("Total Element: " + options.size());
		for (WebElement option : options) {
			
			if(option.getText().equalsIgnoreCase("India"))
			{
				System.out.println(option.getText());
				action.moveToElement(option).click().perform();
				// Time delay
				Thread.sleep(2000);
				break;
				
			}
		    System.out.println(option.getText());
		    // Time delay
			Thread.sleep(2000);
		}


		
		
		
		
		// Time delay
		Thread.sleep(5000);
										
		// close windows
		driver.quit();
	}

}





/*

public class Assignment_Auto_Suggest_Dropdown {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																					
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
		
		// click on auto suggest dropdown 
		WebElement auto_dropdow = driver.findElement(By.cssSelector("input#autocomplete"));
		auto_dropdow.click();
		
		auto_dropdow.sendKeys("ind");
		
		
		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);

		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);
		 
		driver.findElement(By.id("autocomplete")).sendKeys(Keys.DOWN);

		System.out.println(driver.findElement(By.id("autocomplete")).getAttribute("value")); 


		
		// Time delay
		Thread.sleep(5000);
										
		// close windows
		driver.quit();
		
		

}




*/