package Assignments;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment_Synchronization_ExplicitWait {
	
	
	
	
	public static void login_page(WebDriver driver, WebDriverWait wait) throws InterruptedException {
		
		
		
		// Fetch the username using the xpath : //p[contains(text(), '(username is ')]//b[1]/i
		String fetch_username = driver.findElement(By.xpath("//p[contains(text(), '(username is ')]//b[1]/i")).getText();
		System.out.println("Username : "+fetch_username);
		
		// Fetch the password using the xpath : //p[contains(text(), '(username is ')]//b[2]/i
		String fetch_password = driver.findElement(By.xpath("//p[contains(text(), '(username is ')]//b[2]/i")).getText();
		System.out.println("Password : "+fetch_password);
		
		// Fill username in input field of username 
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys(fetch_username);
		
		// Fill password in input field of username
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys(fetch_password);
		
		// Time delay 
		Thread.sleep(3000);
		
		// Click on User radio button using xpath  :  //input[@id='usertype' and @value='user']
		WebElement user_radio_btn = driver.findElement(By.xpath("//input[@id='usertype' and @value='user']"));
		user_radio_btn.click();
		
		//Thread.sleep(3000);

		// after selecting the on User radio button a popup appear we have click on okay button
		//WebElement popup_okay_btn = driver.findElement(By.id("okayBtn"));
		WebElement popup_okay_btn = wait.until(ExpectedConditions.elementToBeClickable(By.id("okayBtn")));
		popup_okay_btn.click();
		
		// Select option from dropdown as consultant
		WebElement role_dropdown = driver.findElement(By.xpath("//select[@data-style='btn-info']"));
		role_dropdown.click();
		
		Select select = new Select(role_dropdown);
		
		select.selectByVisibleText("Consultant");
		
		// Ensure that Consultant option is selected
		// get the selected item
		WebElement selected_ele =select.getFirstSelectedOption();
		// Get text of the selected item 
		String selected_option = selected_ele.getText();
		
		// Check the selected item is Consultant or not 
		if("Consultant".equalsIgnoreCase(selected_option)) {
			System.out.println("Verification Passed : Consultant is Selected.");
		}
		else {
			System.out.println("Verification Failed : Consultant is not Selected.");
		}
		
		// Check Terms and condition checkbox
		WebElement terms = driver.findElement(By.id("terms"));
		terms.click();
		
		// Click on Sign in button 
		WebElement sign_btn = driver.findElement(By.id("signInBtn"));
		sign_btn.click();
	}
	
	
	public static void add_to_cart(WebDriver driver, WebDriverWait wait) throws InterruptedException{
		
		System.out.println("Inside add to cart function");
		
		// Using the xpath : (//button[@class='btn btn-info' and contains(text(), 'Add')])[1]
		//WebElement first_item = driver.findElement(By.xpath("(//button[@class='btn btn-info' and contains(text(), 'Add')])[1]"));
		//WebElement first_item = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class='btn btn-info' and contains(text(), 'Add')])[1]")));
		//first_item.click();
		
		// Time Delay
		Thread.sleep(2000);
		
		// we can also use xpath : //app-card[@class='col-lg-3 col-md-6 mb-3'] to locate the total element are present on the 
		// web page to purchase those
		
		// We have to add all the item to cart 
		// using xpath : //button[@class='btn btn-info']
		
		List<WebElement> items = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy( By.xpath("//button[@class='btn btn-info']")));
		items.forEach(element ->{
			element.click();
		});
		
		// Time Delay
		Thread.sleep(3000);
		
		// After adding items to cart
		//go to checkout btn click on it using xpath : //a[contains(text(), 'Checkout')]
		WebElement checkout_btn = driver.findElement(By.xpath("//a[contains(text(), 'Checkout')]"));
		checkout_btn.click();
		
	}
	
	public static void payment_window(WebDriver driver, WebDriverWait wait) throws InterruptedException {
		
		// Time delay 
		Thread.sleep(3000);
		
		// After clicked on Checkout button puchase window will open 
		// Click on checkout button using the xpath : //button[contains(text(), 'Checkout ')]
		WebElement buy_btn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(), 'Checkout ')]")));
		buy_btn.click();
		
		Thread.sleep(5000);
		
		// Delivery location fill the location xpath  :  //input[@id='country']
		WebElement delivery_location = driver.findElement(By.xpath("//input[@id='country']"));
		delivery_location.sendKeys("Ind");
		
		// xpath for india   //div[@class='suggestions']//ul//li//a[contains(text(), 'India')]
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='suggestions']//ul//li//a")));
		
		// list of auto suggestions 
		List<WebElement> countries = driver.findElements(By.xpath("//div[@class='suggestions']//ul//li//a"));
		
		// Travese through the list of countries and find your's
		for(WebElement country : countries) {
			 
			// Check the list of options and find India
			if(country.getText().equalsIgnoreCase("India")) {
				System.out.println("Selected Country : "+country.getText());
				country.click();
				break;
			}
		}
		
		// Time Delay
		Thread.sleep(5000);
		
		// agree term and policy checkbox 
		//WebElement agree_term_chkbox = driver.findElement(By.id("checkbox2"));
		//WebElement agree_term_chkbox = wait.until(ExpectedConditions.elementToBeClickable(By.id("checkbox2")));
		//WebElement agree_term_chkbox  = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("checkbox2")));
		
		WebElement agree_term_chkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(), ' I agree with the ')]")));
		agree_term_chkbox.click();
		
		//WebElement again_agree_term_chkbox  = wait.until(ExpectedConditions.elementToBeClickable(By.id("checkbox2")));
		//again_agree_term_chkbox.click();
		
		// Time Delay
		Thread.sleep(5000);
		
		// agree term and policy link
		WebElement agree_term_link = driver.findElement(By.xpath("//a[contains(text(),'term & Conditions')]"));
		agree_term_link.click();
		
		// Time Delay
		Thread.sleep(3000);
		
		WebElement close_agree_term_popup = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Close')]")));
		close_agree_term_popup.click();
		
		
		// Click on Purchase button using xpath : //input[@value='Purchase' and @type='submit']
		WebElement purchase_btn = driver.findElement(By.xpath("//input[@value='Purchase' and @type='submit']"));
		purchase_btn.click();
		
		// Confirmation message about your purchase 
		WebElement confirmations = driver.findElement(By.xpath("//div[@class='alert alert-success alert-dismissible']"));
		String confirmations_msg = confirmations.getText();
		System.out.println("\nConfirmation Message : "+confirmations_msg);
		System.out.println();

        // Optionally, if you need more control:
        // Remove unwanted parts if needed
        // Example: Remove specific unwanted characters
        String cleanedText = confirmations_msg.replaceAll("×", "").trim();
        System.out.println("Confirmation Message : " + cleanedText);
		
		
		 // Use JavaScript to get the inner text excluding specific elements
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String script = "return arguments[0].textContent.replace('×', '').trim();";
        
        String cleaned_text = (String) js.executeScript(script, confirmations);
        
        System.out.println("\nCleaned text : " + cleaned_text);
        
        // Trim and normalize text
        cleaned_text = cleaned_text.trim();
        
        // Debugging information
        System.out.println("Cleaned text length: " + cleaned_text.length());
        System.out.println("Expected text length: " + "Success! Thank you! Your order will be delivered in next few weeks :-).".length());
        System.out.println("Cleaned text: [" + cleaned_text + "]");
        System.out.println("Expected text: [Success! Thank you! Your order will be delivered in next few weeks :-).]");
        
        
        
		
		
		if(cleaned_text.equalsIgnoreCase("Success! Thank you! Your order will be delivered in next few weeks :-).")) {
			
			System.out.println("Items are Purchase successfully. Your order will deleivered.");
			
			js.executeScript("alert('Test Passed :\\n"+cleaned_text+"');");
			
			// Handle the alert
			Alert alert = driver.switchTo().alert();
			
			// Time Delay
			Thread.sleep(3000);
			
			// Accept alert
			alert.accept();
			
			
		}else {
			
			System.out.println("\nSomething went wrong. Please try again.");
			js.executeScript("alert('Test Failed : \\nSomething went wrong. Please try again.');");
			
			// Handle the alert
			Alert alert = driver.switchTo().alert();
						
			// Time Delay
			Thread.sleep(3000);
						
			// Accept alert
			alert.accept();
			
		}
		
	}

	public static void main(String[] args) throws InterruptedException {
		
			// https://rahulshettyacademy.com/loginpagePractise/
		
			// Launch Chrome Browser
			WebDriver driver = new ChromeDriver();						
						
			// Maximize Browser window
			driver.manage().window().maximize();
					
			// implicit wait for 5 second for every line of code 
			//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
					
			// Explicit apply to only specific element
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
																		
			// Open url :  https://rahulshettyacademy.com/loginpagePractise/
			driver.get("https://rahulshettyacademy.com/loginpagePractise/");
			
			// calling the login function 
			login_page(driver, wait);
			
			// add item to cart 
			add_to_cart(driver, wait);
			
			// Buy added items
			payment_window(driver, wait);



	}

}


/*
 
Complete the Assignment and post the working code here.

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.Assert;



import java.time.Duration;

import java.util.List;



public class CheckboxTest {

    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

        driver.get("https://rahulshettyacademy.com/loginpagePractise/");

        driver.findElement(By.xpath("//input[@id='username']")).sendKeys("rahulshettyacademy");

        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("learning");

        driver.findElement(By.xpath("//span[@value='User']")).click();

        wait.until(ExpectedConditions.alertIsPresent());

        driver.switchTo().alert().accept();

        WebElement dropdown = driver.findElement(By.xpath("//select[@class='form-control']"));

        dropdown.click();

        dropdown.findElement(By.xpath("//option[@value='Consultant']")).click();

        driver.findElement(By.xpath("//input[@id='terms']")).click();

        driver.findElement(By.xpath("//input[@id='signInBtn']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@class='col-lg-3 col-md-6 mb-3']")));

        List<WebElement> products = driver.findElements(By.xpath("//td[@class='col-lg-3 col-md-6 mb-3']"));

        for (WebElement product : products) {

            product.findElement(By.xpath("//button[@class='btn btn-info']")).click();

        }

        driver.findElement(By.xpath("//a[@class='nav-link btn btn-primary']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@class='col-sm-8 col-md-6']")));

        List<WebElement> cartItems = driver.findElements(By.xpath("//td[@class='col-sm-8 col-md-6']"));

        Assert.assertEquals(cartItems.size(), products.size());

        driver.quit();

    }

}


  
 
 */


/*
 
 package seleniumExamples.locators.TchniqueToAutomateWebElements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LoginPagePractice {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        //Maximized mode to make objects visible to Selenium
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.get("https://rahulshettyacademy.com/loginpagePractise/");
        driver.findElement(By.cssSelector("input[name='username'] ")).sendKeys("rahulshettyacademy");
        driver.findElement(By.cssSelector("input[name='password'] ")).sendKeys("learning");
        driver.findElement(By.cssSelector("label.customradio:nth-child(2) .checkmark")).click();

        Duration waitTime = Duration.ofSeconds(10);
        WebDriverWait wait = new WebDriverWait(driver, waitTime);
        WebElement popupElement =
                wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".modal-dialog .modal-content")));

        if(popupElement.isDisplayed()){
            WebElement okButton = popupElement.findElement(By.id("okayBtn"));
            okButton.click();
        }

        driver.findElement(By.cssSelector("select.form-control")).click();
        driver.findElement(By.cssSelector("option[value='consult']")).click();
        driver.findElement(By.cssSelector("input[id='terms']")).click();
        driver.findElement(By.cssSelector("input[value='Sign In']")).click();

        String[] itemsNeeded = {"iphone", "Samsung", "Nokia", "Blackberry"};

        addItems(driver, itemsNeeded);
        driver.findElement(By.xpath("//a[@class='nav-link btn btn-primary']")).click();

        driver.close();
    }

    public static void addItems(WebDriver driver, String[] itemsNeeded) {
        int j = 0;
        List<WebElement> products = driver.findElements(By.cssSelector("app-card-list"));
        for (int i = 0; i < products.size(); i++) {
            String[] name = products.get(i).getText().split(" ");
            String formattedName = name[0].trim();

            List itemsNeededList = Arrays.asList(itemsNeeded);
            if (itemsNeededList.contains(formattedName)) {
                j++;
                //click on Add to cart
                driver.findElements(By.xpath("//div[@class='card-footer']/button")).get(i).click();
                if (j == itemsNeeded.length) {
                    break;

                }
            }
        }
    }
}

  
 */
