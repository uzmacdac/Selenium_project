package Assignments;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Assignment_Stream_Print_Unique_Number {

	public static void main(String[] args) {
		
		// Print unique Number from the list
		// Sort the arrays 
		List<Integer> list = Arrays.asList(3, 2, 2, 5, 4, 5, 6, 1, 7, 1, 1);
		
		// Convert list to stream
		System.out.println("Unique Numbers : ");
		list.stream()
		.distinct()
		.forEach(s->System.out.println(s));
		
		System.out.println("------------------------------------------------");
		System.out.println("Sort the stream : ");
		list.stream()
		.distinct()
		.sorted()
		.forEach(s->System.out.println(s));
		
		System.out.println("------------------------------------------------");
		System.out.println("Collect  result : ");
		List<Integer> sorted_list = list.stream()
				.distinct()
				.sorted()
				.collect(Collectors.toList());
		System.out.println(sorted_list.get(2));
	}

}
