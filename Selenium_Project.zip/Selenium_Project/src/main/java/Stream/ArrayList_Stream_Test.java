package Stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ArrayList_Stream_Test {
	
	//@Test
	public void regular()
	{
		// Create ArrayList 
				ArrayList<String> name = new ArrayList<String>();
				
				// count
				int count = 0;
				
				// Add elements in List 
				name.add("Payal");
				name.add("Raj");
				name.add("Arriyan");
				name.add("Akhil");
				name.add("Rizan");
				name.add("Ilhan");
				name.add("Haadi");
				
				// Traverse through the list
				for(int i=0 ; i<name.size() ; i++)
				{
					String actual_name = name.get(i);
					if(actual_name.startsWith("A"))
					{
						count++;
					}
				}
				
				System.out.println("Count  : "+count);
				
	}
	
	//@Test
	public void streamFilter()
	{
		// Create ArrayList 
		ArrayList<String> name = new ArrayList<String>();
		
		// count
		int count = 0;
		
		// Add elements in List 
		name.add("Payal");
		name.add("Raj");
		name.add("Arriyan");
		name.add("Akhil");
		name.add("Rizan");
		name.add("Ilhan");
		name.add("Haadi");
		
		// Using stream
		Long count_name = name.stream().filter(s->s.startsWith("A")).count();
		System.out.println("Count : "+count_name);
		
		long d = Stream.of("Ajay", "Priyanka", "Disha", "Debolina", "Pooja", "Shaileja", "Minakshi").filter(s ->
		{
			//s.startsWith("A");
			if(s.startsWith("A"))
				return true;
			return false;
			
		}).count();
		System.out.println("Count : "+d);
		
	}

	//@Test
	public void printNamesUsingFilter() {
		// Create ArrayList 
		ArrayList<String> name = new ArrayList<String>();
				
		// count
		int count = 0;
				
		// Add elements in List 
		name.add("Payal");
		name.add("Raj");
		name.add("Sid");
		name.add("Aariyan");
		name.add("Akhil");
		name.add("Rizan");
		name.add("Ilhan");
		name.add("Haadi");
		
		// Print the names whose length > 4
		name.stream().filter(s-> s.length()>4).forEach(s-> System.out.println(s));
		
		System.out.println("Need only two result : ");
		
		// Print the names whose length > 4 but give me 2 result
		name.stream().filter(s-> s.length()>4).limit(2).forEach(s-> System.out.println(s));
		
		
	}
	
	// un-comment to run
	//@Test
	public void streamMap() {
		// Map
		// Print the name whose last letter is a 
		// that a convert to uppercase
		Stream.of("Ajay", "Priyanka", "Disha", "Debolina", "Pooja", "Shaileja", "Minakshi")
		.filter(s->s.endsWith("a"))
		.map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		
		System.out.println("------------------------------------------------");
		System.out.println("Sort");
		
		// Sort the names 
		Stream.of("Ajay", "Priyanka", "Disha", "Debolina", "Pooja", "Shaileja", "Minakshi")
		.filter(s->s.startsWith("D"))
		.sorted()
		.map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		
		System.out.println("------------------------------------------------");
		System.out.println("Concatenate two list into stream : ");
		// Merging two different list 
		// Concatenate
		// Create ArrayList 
		ArrayList<String> name_1 = new ArrayList<String>();
				
		// count
		int count = 0;
				
		// Add elements in List 
		name_1.add("Payal");
		name_1.add("Raj");
		name_1.add("Sid");
		name_1.add("Aariyan");
		
		List<String> name_2 = Arrays.asList("Ajay", "Priyanka", "Disha", "Debolina", "Pooja", "Shaileja", "Minakshi");
		
		Stream newStream = Stream.concat(name_1.stream(), name_2.stream());
		//newStream.sorted().forEach(s->System.out.println(s));
		
		// find element in stream anyMatch() return boolean value 
		boolean flag = newStream.anyMatch(s->s.equals("Disha"));
		System.out.println(flag);
		Assert.assertTrue(flag);
		
		
	}
	
	@Test
	public void streamCollect() {
		
		// Collect the result
	
		// Print the name whose last letter is a 
		// that a convert to uppercase
		List<String> list = Stream.of("Ajay", "Priyanka", "Disha", "Debolina", "Pooja", "Shaileja", "Minakshi")
		.filter(s->s.endsWith("a"))
		.map(s->s.toUpperCase())
		.collect(Collectors.toList());
		
		// Print first result
		System.out.println(list.get(0));
		
	}
	
}
