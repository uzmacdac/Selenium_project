package Stream;

import java.util.ArrayList;

public class ArrayList_Stream {

	public static void main(String[] args) {
		
		// Create ArrayList 
		ArrayList<String> name = new ArrayList<String>();
		
		// count
		int count = 0;
		
		// Add elements in List 
		name.add("Payal");
		name.add("Raj");
		name.add("Arriyan");
		name.add("Akhil");
		name.add("Rizan");
		name.add("Ilhan");
		name.add("Haadi");
		
		// Traverse through the list
		for(int i=0 ; i<name.size() ; i++)
		{
			String actual_name = name.get(i);
			if(actual_name.startsWith("A"))
			{
				count++;
			}
		}
		
		System.out.println("Count  : "+count);
		

	}

}
