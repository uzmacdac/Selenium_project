package Selenium_Wait;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class Fluent_Wait {

	public static void main(String[] args) {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
							
		// Maximize Browser window
		driver.manage().window().maximize();
											
		// Open url : https://the-internet.herokuapp.com/dynamic_loading/1
		driver.get("https://the-internet.herokuapp.com/dynamic_loading/1");
		
		// Using the Fluent wait 
		//driver.findElement(By.cssSelector("div#start button"));
		driver.findElement(By.cssSelector("[id='start'] button")).click();
		
		// Fluent Wait 
		Wait wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(3))
				.ignoring(NoSuchElementException.class);
		
		// Fluent wait does not give any predefined function we have create the custom function for that
		WebElement element = (WebElement) wait.until(new Function<WebDriver, WebElement>() {
            public WebElement apply(WebDriver driver) {
            	if(driver.findElement(By.cssSelector("[id='finish'] h4")).isDisplayed())
            	{
            		return driver.findElement(By.cssSelector("[id='finish'] h4"));
            	}
            	else
            		return null; // Replace with your locator
            }
        });
		
		System.out.println(driver.findElement(By.cssSelector("[id='finish'] h4")).getText());

	}

}
