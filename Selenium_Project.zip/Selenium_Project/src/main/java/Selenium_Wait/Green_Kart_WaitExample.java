package Selenium_Wait;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Green_Kart_WaitExample {
	
	public void addItems(WebDriver driver, String[] itemsNeeded) {
		
		
		
		// size of itemsNeeded - 3 
		int size_itemsNeeded = itemsNeeded.length;
		
		// counter to check the item itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"};
		int counter = 0;
		
		// if we are locating any element in this GreenKart we will get almost 30 item matching 
		//if we have to locate element then we have to traverse through the each element and check the desired item index then locate the element 
		List<WebElement> product_list = driver.findElements(By.cssSelector("h4.product-name"));
				
		// Total 30 item are present on the page total_product = 30
		int total_product = product_list.size();
							
		// Traverse through the each element until find the desired one
		for(int i=0 ; i<total_product ; i++)
		{
			// Cucumber - 1 Kg,  Brocolli - 1 Kg
			// We have to string Brocolli - 1 Kg in such way that only Brocoli is capture, so to capture Brocolli we to have split by - (Brocolli, - 1 Kg)
			// Brocolli - 1 Kg  (spliting by - )
			// after spliting : Brocolli ,  1 Kg
			// Using split() it gives array 
			// product_name = {"Brocolli ", " 1 Kg"} here you can see white spaces also coming so we have to remove it to match with the itemes in
			// the array String[] itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"};  
			String[] product_name_arr = product_list.get(i).getText().split("-");
				
			// trim() removes leading and trailing whitespace (remove whitespaces from left and right side of the string)
			String product_name = product_name_arr[0].trim();
					
			// before comparing the product name we have to remove  - 1 Kg from the product_name 
					
					
			// Check whether the product name extracted is present in the array or not
			// Convert array into arraylist 
			List itemsNeededList = Arrays.asList(itemsNeeded);
					
			// check the product name contain cucumber 
			if(itemsNeededList.contains(product_name))
			{
				counter++;
						
				// clcik on the product to add to cart (it is not static beacuse after click on 'ADD TO CART' button the text changes to 'ADDED' )
				// static path : //div[@class='product-action']/button   -> it is static 
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
						
						
				if(counter == size_itemsNeeded )
				{
					break;
				}
						
			}
					
		}
		
	}

	// 
	public static void purchaseItems(WebDriver driver, WebDriverWait wait) throws InterruptedException {
		
			//
			// Javascript  
			JavascriptExecutor js = (JavascriptExecutor) driver;
			
			
		
			// click on the cart icon
			WebElement cart_ele = driver.findElement(By.cssSelector("img[alt='Cart']"));
			cart_ele.click();
					
			// Click on the Procced to checkout button
			WebElement checkout_btn = driver.findElement(By.xpath("//button[contains(text(), 'PROCEED TO CHECKOUT')]"));
			checkout_btn.click();
			
			// wait until the promocode element visible on the web page
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input.promoCode")));
				
			// input Enter promo code - rahulshettyacademy
			WebElement promo_code = driver.findElement(By.cssSelector("input.promoCode"));
			promo_code.sendKeys("rahulshettyacademy");
					
			// Click on the Apply button using xpath : //button[@class='promoBtn']
			WebElement apply_btn = driver.findElement(By.xpath("//button[@class='promoBtn']"));
			apply_btn.click();
			
			// wait until the promocode element visible on the web page
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='promoInfo']")));
					
			// get info msg after applying promo code using xpath : //span[@class='promoInfo']
			WebElement promo_info = driver.findElement(By.xpath("//span[@class='promoInfo']"));
			String promo_msg = promo_info.getText();
			String expected = "Code applied ..!";
			System.out.println("Message : "+promo_msg);

			//Assert.assertEquals(promo_msg, expected, "The actual value does not match the expected value.");
				
			// Use assertEquals with a custom failure message that includes the expected value
		    Assert.assertEquals(promo_msg, expected, 
		    		 String.format("Assertion failed: The actual value '%s' does not match the expected value '%s'.", promo_msg, expected));
		     
		    // Perform assertion
		    try {
		    	
		    	
                Assert.assertEquals(promo_msg, expected, "Assertion failed: The actual value does not match the expected value.");
                String message = String.format("Test Passed : Expected '%s' and actual value '%s' are same.", expected, promo_msg);
                // Popup 
                js.executeScript("alert(arguments[0]);", message);
                
                // Alert 
    			Alert alert = driver.switchTo().alert();
                
    			// Time delay
    			Thread.sleep(5000);
    			
    			// accept aler
                alert.accept();
                
            } catch (AssertionError e) {
            	
            	
                // If assertion fails, display an alert with the result
                String message = String.format("Assertion failed: Expected '%s', but got '%s'.", expected, promo_msg);
                ((JavascriptExecutor) driver).executeScript("alert(arguments[0]);", message);
                
                // Alert 
    			Alert alert = driver.switchTo().alert();
    			
    			// Time delay
    			Thread.sleep(5000);
    			
    			// accept alert
                alert.accept();
                
                throw e; // Re-throw the exception to ensure the test still fails
            }

		
	}
	
	
	public static void main(String[] args) throws InterruptedException {
			
		Green_Kart_WaitExample obj = new Green_Kart_WaitExample();
		
			// https://rahulshettyacademy.com/seleniumPractise/#/
		
			// Launch Chrome Browser
			WebDriver driver = new ChromeDriver();
				
			// array of product
			String[] itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"}; 
				
			// Maximize Browser window
			driver.manage().window().maximize();
			
			// implicit wait for 5 second for every line of code 
			//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
			// Explicit apply to only specific element
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
																
			// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/
			driver.get("https://rahulshettyacademy.com/seleniumPractise/");
			
			// Time Delay : we have to give time delay to load all product on the page because here we are checking the total number total_product
			// if we not give the delay total_product = 0 it does not enter in the for loop
			Thread.sleep(5000);
			
			
			
			obj.addItems(driver, itemsNeeded);
			
			purchaseItems(driver, wait);
			
			
	}

}


/*


public class Green_Kart_WaitExample {
	
	public void addItems(WebDriver driver, String[] itemsNeeded) {
		
		// size of itemsNeeded - 3 
		int size_itemsNeeded = itemsNeeded.length;
		
		// counter to check the item itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"};
		int counter = 0;
		
		// if we are locating any element in this GreenKart we will get almost 30 item matching 
		//if we have to locate element then we have to traverse through the each element and check the desired item index then locate the element 
		List<WebElement> product_list = driver.findElements(By.cssSelector("h4.product-name"));
				
		// Total 30 item are present on the page total_product = 30
		int total_product = product_list.size();
							
		// Traverse through the each element until find the desired one
		for(int i=0 ; i<total_product ; i++)
		{
			// Cucumber - 1 Kg,  Brocolli - 1 Kg
			// We have to string Brocolli - 1 Kg in such way that only Brocoli is capture, so to capture Brocolli we to have split by - (Brocolli, - 1 Kg)
			// Brocolli - 1 Kg  (spliting by - )
			// after spliting : Brocolli ,  1 Kg
			// Using split() it gives array 
			// product_name = {"Brocolli ", " 1 Kg"} here you can see white spaces also coming so we have to remove it to match with the itemes in
			// the array String[] itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"};  
			String[] product_name_arr = product_list.get(i).getText().split("-");
				
			// trim() removes leading and trailing whitespace (remove whitespaces from left and right side of the string)
			String product_name = product_name_arr[0].trim();
					
			// before comparing the product name we have to remove  - 1 Kg from the product_name 
					
					
			// Check whether the product name extracted is present in the array or not
			// Convert array into arraylist 
			List itemsNeededList = Arrays.asList(itemsNeeded);
					
			// check the product name contain cucumber 
			if(itemsNeededList.contains(product_name))
			{
				counter++;
						
				// clcik on the product to add to cart (it is not static beacuse after click on 'ADD TO CART' button the text changes to 'ADDED' )
				// static path : //div[@class='product-action']/button   -> it is static 
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
						
						
				if(counter == size_itemsNeeded )
				{
					break;
				}
						
			}
					
		}
		
	}

	public static void main(String[] args) throws InterruptedException {
			
		Green_Kart_WaitExample obj = new Green_Kart_WaitExample();
		
			// https://rahulshettyacademy.com/seleniumPractise/#/
		
			// Launch Chrome Browser
			WebDriver driver = new ChromeDriver();
				
			// array of product
			String[] itemsNeeded = {"Cucumber", "Brocolli", "Beetroot"}; 
				
			// Maximize Browser window
			driver.manage().window().maximize();
			
			// wait for 5 second
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
																
			// Open url :  https://rahulshettyacademy.com/seleniumPractise/#/
			driver.get("https://rahulshettyacademy.com/seleniumPractise/");
			
			// Time Delay : we have to give time delay to load all product on the page because here we are checking the total number total_product
			// if we not give the delay total_product = 0 it does not enter in the for loop
			Thread.sleep(5000);
			
			obj.addItems(driver, itemsNeeded);
			
			// click on the cart icon
			WebElement cart_ele = driver.findElement(By.cssSelector("img[alt='Cart']"));
			cart_ele.click();
			
			// Click on the Procced to checkout button
			WebElement checkout_btn = driver.findElement(By.xpath("//button[contains(text(), 'PROCEED TO CHECKOUT')]"));
			checkout_btn.click();
			
			// input Enter promo code - rahulshettyacademy
			WebElement promo_code = driver.findElement(By.cssSelector("input.promoCode"));
			promo_code.sendKeys("rahulshettyacademy");
			
			// Click on the Apply button using xpath : //button[@class='promoBtn']
			WebElement apply_btn = driver.findElement(By.xpath("//button[@class='promoBtn']"));
			apply_btn.click();
			
			// get info msg after applying promo code using xpath : //span[@class='promoInfo']
			WebElement promo_info = driver.findElement(By.xpath("//span[@class='promoInfo']"));
			String promo_msg = promo_info.getText();
			String expected = "Code applied ..!";
			System.out.println("Message : "+promo_msg);

			//Assert.assertEquals(promo_msg, expected, "The actual value does not match the expected value.");
		
			// Use assertEquals with a custom failure message that includes the expected value
            Assert.assertEquals(promo_msg, expected, 
                String.format("Assertion failed: The actual value '%s' does not match the expected value '%s'.", promo_msg, expected));

	}

}


*/