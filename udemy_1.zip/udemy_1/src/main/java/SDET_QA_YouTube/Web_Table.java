package SDET_QA_YouTube;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Web_Table {
	
	// https://blazedemo.com/reserve.php
	
	// https://opensource-demo.orangehrmlive.com/auth/login

	public static void main(String[] args) throws InterruptedException {
	
		// https://testautomationpractice.blogspot.com/
		
		//  https://demo.opencart.com/admin/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// Explicit wait 
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://demo.opencart.com/admin/
		driver.get("https://demo.opencart.com/admin/");
		
		WebElement username = driver.findElement(By.id("input-username"));
		username.clear();
		
		// Time delay 
		Thread.sleep(3000);
		
		username.sendKeys("demo");
		
		WebElement password = driver.findElement(By.id("input-password"));
		password.clear();
		
		// Time delay 
		Thread.sleep(3000);
		
		password.sendKeys("demo");
		
		// Time delay 
		Thread.sleep(3000);
		
		WebElement login_btn = driver.findElement(By.xpath("//button[@type=\"submit\" and  contains(text(), 'Login')]"));
		login_btn.click();
		
		
		// popup windoe appeat sometime, to handle such window do the following steps
		// it will close the window if it appear or available
//		if(driver.findElement(By.xpath("//button[@class='btn-class']")).isDisplayed())
//		{
//			driver.findElement(By.xpath("//button[@class='btn-class']")).click();
//		}
		
		// Time delay 
		Thread.sleep(5000);
		
		// Locate  the Customer main menue  element using xpath : //a[@href='#collapse-5' and @class='parent collapsed']
		// or use xpath : //a[@class='parent collapsed'][normalize-space()='Customers']
		
		WebElement customers_dropdown_menue = driver.findElement(By.xpath("//a[@href='#collapse-5' and @class='parent collapsed']"));
		customers_dropdown_menue.click();
		
		// using xpath locate the dropdown option : //a[contains(text(), 'Customers')]
		
		//WebElement customer_option = driver.findElement(By.xpath("//a[contains(text(), 'Customers')]"));
		
		// use xpath : //ul[@id='collapse-5']//li//a[contains(text(), 'Customers')]
		WebElement customer_option = driver.findElement(By.xpath("//ul[@id='collapse-5']//li//a[contains(text(), 'Customers')]"));
		customer_option.click();
		

		// Time delay 
		Thread.sleep(3000);
		
		
		// Handling the dynamic Web Table
		// using xpath : //div[contains(text(), 'Showing')]  or use this one //div[contains(text(), 'Pages')
		//WebElement pages_ele = driver.findElement(By.xpath("//div[contains(text(), 'Showing')]"));
		String text = driver.findElement(By.xpath("//div[contains(text(), 'Pages')]")).getText();
		
		// text = Showing 1 to 10 of 6816 (682 Pages) we have only fetch 682 from the string we are gonna use substring 
		// using substring
		int total_page = Integer.parseInt(text.substring(text.indexOf("(")+1, text.indexOf("Pages")-1));
		System.out.println("Total Pages : "+total_page);
		
		// Time delay 
		Thread.sleep(3000);
		
		// traverse through the pages
		for(int i=1 ; i<3 ; i++)
		{
			if(i>1)
			{
				System.out.println("Inside if condition ");
				
				// xpath : //ul[@class='pagination']//*[text()='2'] here 2 will be change so we have give i instead 2
				//WebElement  active_page = driver.findElement(By.xpath("//ul[@class='pagination']//*[text()="+i+"]"));
				//WebElement active_page = wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//ul[@class='pagination']//*[text()="+i+"]"))));
				WebElement active_page = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='pagination']//*[text()="+i+"]")));
				active_page.click();
				// Time delay 
				Thread.sleep(3000);
			}
			
			// Time delay 
			Thread.sleep(3000);
			
			// reading the data 
			// using table xpath  :  //table[@class='table table-bordered table-hover']
			// access row of the table using xpath : //table[@class='table table-bordered table-hover']//tbody//tr
			List<WebElement> total_row_element = driver.findElements(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr"));
			int total_row = total_row_element.size();
			System.out.println("Total rows : "+total_row);
			
			for(int row=1 ; row<=total_row ; row++)
			{
				// customer name xpath : //td[@class='text-start' and not(./small)]/text()  -> Does not include  Enabled
				//  //table[@class='table table-bordered table-hover']//tbody//tr[row]/td[2][normalize-space() and not(./small)]/text()

				// or  //td[@class='text-start']/text()[normalize-space()]

				
				String customer_name = driver.findElement(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr["+row+"]//td[2]")).getText();
				//String customer_name = driver.findElement(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr["+row+"]//td[2][normalize-space() and not(./small)]/text()")).getText();
				System.out.println("Customer name : "+customer_name);
			}
			
			
		}
		
		
		
	}

}


/*

public class Web_Table {
	
	// https://blazedemo.com/reserve.php

	public static void main(String[] args) {
	
		// https://testautomationpractice.blogspot.com/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
					
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : // https://testautomationpractice.blogspot.com/
		driver.get("https://testautomationpractice.blogspot.com/");
		
		// locate the table element to fetch the total rows 
		// using xpath : //table[@name='BookTable']//tr
		List<WebElement> table_rows = driver.findElements(By.xpath("//table[@name='BookTable']//tr"));
		System.out.println("Total Table rows : "+table_rows.size());
		
		// Total number of coloumn in the table
		List<WebElement> table_columns = driver.findElements(By.xpath("//table[@name='BookTable']//th"));
		System.out.println("Total table columns : "+table_columns);
		
		// traverse through the list 
		for(WebElement col : table_columns)
		{
			System.out.println("Data : "+col.getText());
		}
		
		// Read the data from specific row second row
		//using xpath : //table[@name='BookTable']//tr[2]//td
		List<WebElement> row_2_data = driver.findElements(By.xpath("//table[@name='BookTable']//tr[2]//td"));
		
		// traverse through the list 
		for(WebElement row : row_2_data)
		{
			System.out.println("Data : "+row.getText());
		}
		
		
		
		
		
	}

}

*/