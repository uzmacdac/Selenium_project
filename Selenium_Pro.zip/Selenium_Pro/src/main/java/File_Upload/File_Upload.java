package File_Upload;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class File_Upload {
	
	// Multiple File Upload Demo
	
	// https://davidwalsh.name/demo/multiple-file-upload.php

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
																			
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://davidwalsh.name/demo/multiple-file-upload.php
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		
		// Time delay 
		Thread.sleep(3000);
		
		// Files Path 
		String file_1 = "E:\\\\Selenium_Java\\\\Test_1.txt";
		String file_2 = "E:\\\\Selenium_Java\\\\Test_2.txt";
		
		// uploading file_1 and file_2 simultaneously we have conacatenate the file names with the newline character '\n'
		
		WebElement select_file = driver.findElement(By.xpath("//input[@type='file' and @id='filesToUpload']"));
		select_file.sendKeys(file_1+"\n"+file_2);
		
		// Time delay 
		Thread.sleep(3000);
		
		// Locate the element using xpath : //ul[@id='fileList'] li
		List<WebElement> files_uploaded = driver.findElements(By.xpath("//ul[@id='fileList']//li"));
		
		System.out.println("Total Files : "+ files_uploaded.size());
		
		if(files_uploaded.size()==2)
		{
			// traverse throught the list of files
			
			if(driver.findElement(By.xpath("//ul[@id='fileList']//li[1]")).getText().equals("Test_1.txt") &&
					driver.findElement(By.xpath("//ul[@id='fileList']//li[1]")).getText().equals("Test_2.txt"))
			{
				System.out.println("Files names are matching.");
			}
			else
			{
				System.out.println("Files name are not matching.");
			}
			
		}
		else
		{
			System.out.println("Files are not uploaded.");
		}
		
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();

	}

}


/*
 
	
	// Multiple File Upload Demo
	
	// https://davidwalsh.name/demo/multiple-file-upload.php

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
																			
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://davidwalsh.name/demo/multiple-file-upload.php
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		
		// Time delay 
		Thread.sleep(3000);
		
		// Files Path 
		String file_1 = "E:\\\\Selenium_Java\\\\Test_1.txt";
		String file_2 = "E:\\\\Selenium_Java\\\\Test_2.txt";
		
		// uploading file_1 and file_2 simultaneously we have conacatenate the file names with the newline character '\n'
		
		WebElement select_file = driver.findElement(By.xpath("//input[@type='file' and @id='filesToUpload']"));
		select_file.sendKeys(file_1+"\n"+file_2);
		
		// Time delay 
		Thread.sleep(3000);
		
		// Locate the element using xpath : //ul[@id='fileList'] li
		List<WebElement> files_uploaded = driver.findElements(By.xpath("//ul[@id='fileList']//li"));
		
		System.out.println("Total Files : "+ files_uploaded.size());
		
		if(files_uploaded.size()==2)
		{
			// traverse throught the list of files
			for(WebElement file : files_uploaded)
			{
				// validate that the file is uploaded
				if(file.getText().equals("Test_1.txt") || file.getText().equals("Test_2.txt"))
				{
					js.executeScript("alert('Test Case : Passed\\nFile "+file.getText()+" Successfully Uploaded');");
										
					// Time delay
					Thread.sleep(3000);
					
					// create reference of Alert
					Alert alert = driver.switchTo().alert();
					
					// Accept Alert
					alert.accept();
					
					// print the file name 
					System.out.println("File : "+file.getText());
					
					// Time delay
					Thread.sleep(3000);
				}
				else
				{
					js.executeScript("alert('Test Case : Failed\\nFile is not Uploaded.\\nSomething went wrong');");

					// Time delay
					Thread.sleep(3000);
					
					// create reference of Alert
					Alert alert = driver.switchTo().alert();
					
					// Accept Alert
					alert.accept();
				}
			}
			
			
		}
		else
		{
			System.out.println("Files are not uploaded.");
		}
		
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();

	}

}
 
 
 */

/*

public class File_Upload {
	
	// Single File Upload Demo
	
	// https://davidwalsh.name/demo/multiple-file-upload.php

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
						
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;
																			
		// Maximize Browser window
		driver.manage().window().maximize();
															
		// Open url : https://davidwalsh.name/demo/multiple-file-upload.php
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		
		// Time delay 
		Thread.sleep(3000);
		
		WebElement select_file = driver.findElement(By.xpath("//input[@type='file' and @id='filesToUpload']"));
		select_file.sendKeys("E:\\Selenium_Java\\Test_1.txt");
		
		// Time delay 
		Thread.sleep(3000);
		
		// Locate the element using xpath : //ul[@id='fileList'] li
		WebElement file_uploaded = driver.findElement(By.xpath("//ul[@id='fileList']//li"));
		
		
		// validate that the file is uploaded
		if(file_uploaded.getText().equals("Test_1.txt"))
		{
			js.executeScript("alert('Test Case : Passed\\nFile Successfully Uploaded');");

			// Time delay
			Thread.sleep(3000);
			
			// create reference of Alert
			Alert alert = driver.switchTo().alert();
			
			// Accept Alert
			alert.accept();
			
		}
		else
		{
			js.executeScript("alert('Test Case : Failed\\nFile is not Uploaded.\\nSomething went wrong');");

			// Time delay
			Thread.sleep(3000);
			
			// create reference of Alert
			Alert alert = driver.switchTo().alert();
			
			// Accept Alert
			alert.accept();
		}
		
		// Time delay 
		Thread.sleep(5000);
		driver.quit();

	}

}



*/