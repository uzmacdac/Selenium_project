package Assignments;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Assignment_6_Dynamic_message {

	public static void main(String[] args) throws InterruptedException {
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
		
		// JavascriptExecutor
		JavascriptExecutor js = (JavascriptExecutor) driver;
													
		// Maximize Browser window
		driver.manage().window().maximize();
									
		// Open url : https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		// Locate check box element using CSS Selector :  input[id$='checkBoxOption2']
		WebElement checkbox = driver.findElement(By.cssSelector("input[id$='checkBoxOption2']"));
		String checkbox_text = driver.findElement(By.xpath("//label[@for='benz']")).getText();
		System.out.println("Check Box Text : "+checkbox_text);
		checkbox.click();
	
		
		
		WebElement dropdown = driver.findElement(By.cssSelector("select[id='dropdown-class-example']"));
		dropdown.click();
		
		// Select the dropdown option which is aleady select in chcekbox
		Select select = new Select(dropdown);
		// select the option
		select.selectByVisibleText(checkbox_text);
		
		// Locate the name input 
		WebElement name = driver.findElement(By.xpath("//input[@id='name']"));
		name.sendKeys(checkbox_text);
		
		WebElement alert_btn = driver.findElement(By.xpath("//input[@id='alertbtn']"));		
		alert_btn.click();
		
		// Time delay
		Thread.sleep(2000);
		
		Alert alert = driver.switchTo().alert();
		
		// alert text - Hello  Option2, share this practice page and share your knowledge
		String alert_text = alert.getText();
		
		System.out.println("Alert Text : "+alert_text);
		
		alert.accept();
		
		if(alert_text.contains(checkbox_text))
		{
			System.out.println("option is present ");
			js.executeScript("alert('Test Passed : "
					+ "Text are equal "+checkbox_text+" ');");
			
			// Time delay
			Thread.sleep(6000);
			
			alert.accept();
		}
		
		//Assert.assertEquals(checkbox_text, alert_text);
		
		

		
		
		// Time delay
		Thread.sleep(5000);
		
		// close windows
		driver.quit();
		

	}

}
