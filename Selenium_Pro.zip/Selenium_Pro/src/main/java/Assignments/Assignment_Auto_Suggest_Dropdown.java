package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_Auto_Suggest_Dropdown {

	public static void main(String[] args) throws InterruptedException {
		
		// https://rahulshettyacademy.com/AutomationPractice/
		
		// Launch Chrome Browser
		WebDriver driver = new ChromeDriver();
																
		// Javascript  
		JavascriptExecutor js = (JavascriptExecutor) driver;					
																					
		// Maximize Browser window
		driver.manage().window().maximize();
																					
		// Open url :  https://rahulshettyacademy.com/AutomationPractice/
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");		

		// Time delay
		Thread.sleep(2000);
		
		// click on auto suggest dropdown 
		WebElement auto_dropdow = driver.findElement(By.cssSelector("input#autocomplete"));
		auto_dropdow.click();
		
		auto_dropdow.sendKeys("ind");
		
		
		
		
		
		
		
		
		
		
		// Time delay
		Thread.sleep(5000);
										
		// close windows
		driver.quit();
	}

}
